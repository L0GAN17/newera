# Poučenia z praxe – JIRA delivery a CAB automat (eGOV, 2026)

Zistené pri práci s DELIVERMGT-10999 (Q2, Integrational) a DELIVERMGT-11931 (Q3,
Non Integrational). JIRA sa mení – ak niečo prestane platiť, uprav to tu.

## Chybové hlášky pri tranzíciách

| Hláška | Príčina | Riešenie |
|---|---|---|
| „There must be one Theme or Big Epic linked thru "relates to" link type to this issue" | Delivery nemá nadradený Theme / Big Epic | Pridať link `relates to` na Theme alebo Big Epic. Over typ – bežný Epic nemusí stačiť. |
| „Use "Change Capability" transition and link one or more Capabilities thru "delivers" link type to this issue." | Capabilities sú naviazané opačným smerom (`is delivered by`) alebo len cez Issue Links | Použiť tranzíciu **Change Capability** a naviazať capabilities linkom `delivers` (delivery *delivers* capability). Pôvodné opačné linky skontrolovať. |

## Tranzície Change Epic/Theme, Change Release, Change Capability

- Na schválenej delivery (napr. APPROVED INT) vracajú tieto tranzície delivery do
  **READY FOR INT** – automat ju potom vyhodnotí znova. Pred použitím zváž dopad.
- Obrazovka Change Release ponúka typy linkov:
  - `relates to` + jeden Epic alebo Theme (súvisiaca zmena),
  - `is included in` + jeden Release (zaradenie do releasu),
  - `delivers` + jedna alebo viac capabilities.
- Predvolená hodnota „is installed by" nezodpovedá žiadnemu z týchto účelov.
- Tranzície Create Blank AC Sub-task, TEST Report a Create Acceptance Protocol
  stav delivery nemenia.

## Flagy SECURITY / IARCH / GDPR / ARB

- Flagy sa nastavujú na **capabilities**, nie priamo na delivery (potvrdila IT security).
- Na delivery ich automat doťahuje **len pri kliknutí** na Ready for INT/UAT/LIVE –
  nie priebežne. Oprava na capability sa na delivery prejaví až pri ďalšej tranzícii.
- Pri viacerých capabilities sa berie **najhoršia hodnota**.
- Neintegračná capability má spravidla len ARB = NQ a ostatné flagy nemá → automat
  môže pri Ready for UAT/LIVE vyhodnotiť flagy ako chýbajúce. Pred tranzíciou sa
  ozvi Matúšovi Jaloveckému.
- **NQ = Not Required.** Ak je ARB Design Review na capability NQ, potvrď to s IT
  architektom a zapíš komentár do JIRA (kto a kedy potvrdil) – kvôli auditu.
- Na Big Epicu môže byť „IArch Modeling Required = YES" – potom sa IARCH posúdenie
  nedá vynechať.

## Typické výhrady v CAB Status Notes

| Výhrada | Čo s tým |
|---|---|
| Neštandardný stav defektov | Spustiť Recalculate Defect Count; pri postimplementačnej DE kontaktovať Release manažéra |
| Doplniť IT Security flag / Doplniť IARCH flag | Flagy na capabilities + nová tranzícia (pozri vyššie) |
| Doplniť link na Detailnú analýzu | V záložke Acceptance Criteria je link „undefined" – doplniť platný odkaz |
| Zaslať AC na zadefinovanie | Poslať žiadosť o akceptačné kritériá TímLídrovi L2 prevádzky eGOV |
| Dátum na IR sa nezhoduje s dátumami … v Release R20xx.xx | Upraviť Term na IR podľa okna releasu (over skriptom) alebo Release manažér |
| Dopárovať Feature na IR | V Edit IRs doplniť Included Features; over, či pokrývajú všetky capabilities |

## IR (inštalačná požiadavka)

- Nová IR je v stave DRAFT – over, či stav vyhovuje pre tranzíciu.
- Vyplň všetky termíny INT, UAT aj LIVE; prázdny Term LIVE je častá chyba.
- Jedna Feature nemusí pokrývať všetky capabilities – over zoznam Included Features.
- IR pridaná do už schválenej delivery → PREAPPROVED s výhradou „Pridaná IR" →
  doschválenie cez Release manažéra (offline CAB).

## Záložky Testing a Acceptance Criteria

- Test Statement pri testovaní biznisom: „dodávku bude testovať biznis".
- AC TEST sub-tasky (Disaster recovery, Performance, Penetration) v stave Not Required
  slúžia ako informácia o testoch pre Ready for UAT / LIVE.
- Rovnaký defekt môže byť zadaný dvakrát – pre INT a pre UAT. Pri počítaní ich rozlišuj.

## Prevádzková dokumentácia

- Dodáva ju DISIG: Inštalačný návod, Popis rozhraní, Príručka administrátora.
  Pred prechodom do UAT/LIVE si vyžiadaj potvrdenie, či sa pri dodávke mení.
- Presné miesto v JIRA nie je v procese definované – pravdepodobne sub-task AC DOC
  (`Potrebné overiť`). Link daj aj do komentára delivery a over prístup ITOPS.
- Pozor na nesúlad: AC DOC = Not Required, ale ITOPS Statement = Yes.
- Aktualizáciu dokumentácie DISIG vykazuje nad rámec paušálu – časť obsahu popisuje
  úpravy a integrácie špecifické pre banku.

## JIRA ako nástroj

- JIRA bola v 9/2026 migrovaná do cloudu – kľúče ostali 1:1, zmenila sa URL a vzhľad.
- Notifikácie z testovacej JIRA dodávateľovi nechodili (stav 9/2026). Keď defekt
  prehodíš na DISIG, napíš im aj do chatu.
