# Pravidlá CAB automatu a prechodov delivery

Zdroj: `znalosti/APPROVAL_PROCESSES.md`. Pri zmene procesu aktualizuj oba súbory.

## Obsah
1. Workflow stavov
2. Výsledky CAB automatu
3. Podmienky pre READY FOR INT
4. Podmienky pre READY FOR UAT
5. Podmienky pre READY FOR LIVE
6. Prahy testov a defektov
7. Dátum na IR a okno releasu
8. Akceptačné kritériá a akceptačný protokol

---

## 1. Workflow stavov

NEW → READY FOR INT → (PREAPPROVED INT) → APPROVED INT → READY FOR UAT →
(PREAPPROVED UAT) → APPROVED UAT → READY FOR LIVE → (PREAPPROVED LIVE) →
APPROVED LIVE → DONE. Alternatívne: CANCELLED.

- Prepnutie do READY FOR INT/UAT/LIVE je zároveň žiadosťou o zaradenie do releasu.
- Integračné aj neintegračné dodávky sa prihlasujú rovnako, líšia sa povinné atribúty.

## 2. Výsledky CAB automatu

| Výsledok | Význam | Postup |
|---|---|---|
| **OK** | Splnené všetky požiadavky | GO na inštaláciu |
| **COK** | GO, s výhradami, ktoré nebránia inštalácii (napr. chýbajúca Feature na IR, chýbajúci link na detailnú analýzu) | Inštalovať, výhrady bezodkladne opraviť |
| **PREAPPROVED OK/COK** | OK/COK, ale treba kontrolu Release manažéra | Kontaktovať Release manažéra – posúdi schválenie alebo výnimku od CAB |
| **N/A** | NoGO – nesplnené kritické požiadavky | Odstrániť výhrady, alebo žiadať výnimku od CAB |

**PREAPPROVED nastáva pri:**
- dodávke vo veľkom release (bez výhrady v CAB Status Notes),
- neintegračnej dodávke s výsledkom z ARB, t.j. ARB/IARCH/GDPR/SECURITY flag je iný
  ako NQ (bez výhrady),
- IR pridanej do delivery už schválenej na INT (výhrada „Pridaná IR"),
- dátume na IR mimo okna releasu (výhrada „Dátum na IR sa nezhoduje s dátumami pre
  INT/UAT/LIVE v Release R20xx.xx").

**Release manažéra kontaktuj, keď:**
- je delivery v stave PREAPPROVED (OK/COK) na INT/UAT/LIVE,
- je delivery v Ready for INT s CAB Status = N/A a jedinou výhradou je nezhoda dátumu na IR,
- sa zmenil release alebo scope na už schválenej delivery a automat dal N/A,
- má delivery Evidenčný Epic bez záložky GDPR,
- ide o neštandardnú situáciu.

**Kritické požiadavky (ich nesplnenie = N/A):** absolvovanie procesov – ARB, GDPR,
Cloud Assessment (pri Cloud DE); otestovanie a oprava defektov na testovacích
prostrediach; splnenie akceptačných kritérií a akceptovaný akceptačný protokol
(pri neintegračných zmenách sa spravidla nevyžadujú). Výhrady z procesov treba
odstrániť pred inštaláciou do LIVE.

## 3. Podmienky pre READY FOR INT

- ARB absolvované s výsledkom OK alebo COK (povinné pri integračnej zmene)
- SECURITY – súhlas IT security a schválená bezpečnostná štúdia
- GDPR – súhlas za GDPR
- IARCH – súhlas infraštruktúrnych architektov
- ITOPS Statement – Yes (potvrdené kapacity) alebo Not Required
- Hotová detailná analýza (nalinkovaná)
- Vytvorený delivery plán (Plan of Delivery)
- Alokovaní testeri v tribe-och
- Vyšpecifikované integračné závislosti a závislosti na iných ID v scope releasu
- Vytvorený sub-task IR, na IR pridané konkrétne Features
- Doplnený Test/Defect manager na záložke Testing
- Pri integračnej zmene: vyžiadané akceptačné kritériá (od TímLídra L2 prevádzky)
- Cloud delivery navyše: Agreed Funding, Outsourcing, Risk Analysis

Formulár tranzície Ready for INT (pozorované): ITOPS Statement (Yes / Not Required),
Plan of Delivery (Yes / No), Test Statement (text, napr. „dodávku bude testovať
biznis"), Comment.

## 4. Podmienky pre READY FOR UAT

- Počet defektov pri prechode INT → UAT: A = 0, B = 5, C podľa dohody (presné prahy v bode 6)
- Akceptovaná dodávka za biznis vlastníka / Product Ownera pre inštaláciu do UAT
- Dodaná prevádzková dokumentácia na ITOPS
- Informácia o Performance, Penetračných a DR testoch (plánované / vykonané / nepožadované)
- Súhlas za školiace stredisko
- Počet plánovaných a prejdených test case-ov na INT
- Počet otvorených defektov na INT podľa severity (Recalculate Defect Count)

Formulár tranzície Ready for UAT (pozorované): UAT Business Acceptance, Training
Center Approval, Test Summary INT, QA UAT (význam `Potrebné overiť`), Comment.

## 5. Podmienky pre READY FOR LIVE

- Počet defektov pri prechode UAT → LIVE: A = 0, B = 0, C podľa dohody (presné prahy v bode 6)
- Akceptovaná dodávka za biznis vlastníka / Product Ownera pre LIVE
- Dodaná prevádzková dokumentácia na ITOPS
- Informácia o Performance, Penetračných a DR testoch (vykonané / nepožadované)
- Počet plánovaných a prejdených test case-ov na UAT
- Počet otvorených defektov na UAT podľa severity
- Akceptovaný akceptačný protokol – samostatný sub-task za biznis vlastníka,
  IT prevádzku a IT security (pri integračnej zmene)

## 6. Prahy testov a defektov

**Test case-y** (Pass / Total): OK ≥ 95 % · COK 85–95 % · N/A < 85 %

**Otvorené defekty:**

| Severity | Ready for INT | Ready for UAT | Ready for LIVE |
|---|---|---|---|
| A+ | OK 0 · N/A > 0 | OK 0 · N/A > 0 | OK 0 · N/A > 0 |
| A | OK 0 · N/A > 0 | OK 0 · N/A > 0 | OK 0 · N/A > 0 |
| B | OK 0 · N/A > 0 | OK ≤ 5 · COK ≤ 7 · N/A > 7 | OK 0 · COK ≤ 2 · N/A > 2 |
| C | OK 0 · N/A > 0 | OK ≤ 10 · COK ≤ 12 · N/A > 12 | OK 0 · COK ≤ 4 · N/A > 4 |

Postimplementačné DE vstupujúce do INT, ktoré fixujú defekty z predošlých DE, dostanú
výhradu „Neštandardný stav defektov" alebo „Neštandardný stav testov" → Release manažér.

## 7. Dátum na IR a okno releasu

- **Malý release:** dátum INT, UAT aj LIVE na IR musí byť z intervalu
  ⟨First call INT ; LIVE⟩ vrátane krajných dátumov.
- **Veľký release:** INT z intervalu ⟨First call INT ; Last call INT⟩; UAT sa musí
  rovnať termínu UAT; LIVE sa musí rovnať termínu LIVE.
- Inak PREAPPROVED s výhradou o nezhode dátumu. Platí pre INT, UAT aj LIVE.
- Kontrola: `python scripts/cab_kontrola.py ir <release> --int … --uat … --live …`

## 8. Akceptačné kritériá a akceptačný protokol

- Každá zmena do LIVE musí prejsť akceptáciou a byť schválená na CAB.
- **Integračná zmena:** do LIVE až po splnení akceptačných kritérií a akceptovaní
  protokolu biznis vlastníkom (garant aplikácie), riaditeľom prevádzky IT (resp. B-2)
  a vedúcim IT security.
- **Neintegračná zmena** (jednoplatformová, nemení prevádzku ani performance)
  akceptačné kritériá nevyžaduje.
- Integračnú zmenu je zakázané rozdeliť na dve neintegračné kvôli obídeniu procesu.
- Akceptačné kritériá sa vyžiadajú spolu s návrhom zmeny pred vstupom do INT, vždy
  od TímLídra L2 prevádzky dotknutej aplikácie.
- Žiadosť o akceptačný protokol treba poslať pred prepnutím do Ready for LIVE;
  protokol má byť akceptovaný pred CAB, na ktorom sa schvaľuje LIVE.
