# Release kalendár 2026

Zdroj: `znalosti/APPROVAL_PROCESSES.md`. Na nový rok aktualizuj túto tabuľku aj zoznamy
`RELEASES` a `FREEZES` v `scripts/cab_kontrola.py`.

| Release | Typ | First call INT | Last call INT | UAT | LIVE |
|---|---|---|---|---|---|
| R2026.01.1 | Small | 7.1. | – | 15.1. | 29.1. |
| R2026.02.1 | Small | 4.2. | – | 18.2. | 25.2. |
| R2026.02 | Large | 7.1. | 15.1. | 22.1. | 12.2. |
| R2026.03.1 | Small | 26.2. | – | 5.3. | 12.3. |
| R2026.04.1 | Small | 9.4. | – | 16.4. | 23.4. |
| R2026.05.1 | Small | 29.4. | – | 7.5. | 14.5. |
| R2026.05 | Large | 12.3. | 23.4. | 30.4. | 21.5. |
| R2026.06.1 | Small | 28.5. | – | 11.6. | 18.6. |
| R2026.07.1 | Small | 2.7. | – | 9.7. | 16.7. |
| R2026.08.1 | Small | 29.7. | – | 6.8. | 13.8. |
| R2026.08 | Large | 25.6. | 23.7. | 30.7. | 20.8. |
| R2026.09.1 | Small | 27.8. | – | 3.9. | 10.9. |
| R2026.10.1 | Small | 23.9. | – | 1.10. | 8.10. |
| R2026.11.1 | Small | 21.10. | – | 29.10. | 5.11. |
| R2026.11 | Large | 10.9. | 15.10. | 22.10. | 12.11. |
| R2026.12.1 | Small | – | – | 18.11. | 3.12. |
| R2026.12 | Large | – | – | 19.11. | 9.12. |

## Obdobia freeze a obmedzení

- **19.3.–23.3.** Failover test DC1 Kopčianska (DR) – infraštruktúrny a inštalačný freeze
- **24.9.–28.9.** Failover test DC2 Varšavská (DR) – infraštruktúrny a inštalačný freeze
- **18.11.–10.12.** Refresh INT
- **od 11.12.** Infraštruktúrny a inštalačný freeze
- **11.12.–23.12.** Testy EOY 2026

## Ako vybrať release

1. Zisti plánovaný dátum inštalácie na INT.
2. `python scripts/cab_kontrola.py okno <dátum>` ukáže, ktorý release ho povoľuje,
   a najbližší ďalší malý a veľký release.
3. Termíny INT, UAT a LIVE na IR nastav tak, aby spĺňali pravidlá okna
   (`references/cab-pravidla.md`, bod 7), a over ich príkazom `ir`.
4. Pri R2026.12.1 a R2026.12 kalendár neuvádza First call INT – okno over
   s Release manažérom.
