#!/usr/bin/env python3
"""Predkontrola pravidiel CAB automatu pre eGOV delivery.

Príkazy:
  python cab_kontrola.py kalendar
      Vypíše release kalendár 2026 a obdobia freeze.

  python cab_kontrola.py okno 25.5.2026 [--prostredie INT|UAT|LIVE]
      Ktoré releasy povoľujú daný dátum pre dané prostredie (predvolene INT)
      a ktorý najbližší release sa dá použiť.

  python cab_kontrola.py ir R2026.09.1 --int 27.8. --uat 3.9. --live 10.9.
      Overí dátumy na IR voči oknu releasu. Mimo okna = CAB automat dá
      PREAPPROVED s výhradou o nezhode dátumu.

  python cab_kontrola.py testy UAT --a-plus 0 --a 0 --b 4 --c 1 --tc-total 16 --tc-pass 11
      Vyhodnotí otvorené defekty a úspešnosť test case-ov pre prechod do
      Ready for INT / UAT / LIVE (OK / COK / N/A).

Zdroj pravidiel: APPROVAL_PROCESSES.md (release kalendár 2026, CAB automat).
Kalendár je len pre rok 2026 – na nový rok aktualizuj RELEASES a FREEZES.
Výsledok je čiastková kontrola; CAB automat hodnotí aj flagy, AC a ďalšie podmienky.
"""
import argparse
import re
import sys
from datetime import date

ROK = 2026

# (názov, typ, First call INT, Last call INT, UAT, LIVE) – dátumy "d.m."
RELEASES = [
    ("R2026.01.1", "Small", "7.1.", None, "15.1.", "29.1."),
    ("R2026.02.1", "Small", "4.2.", None, "18.2.", "25.2."),
    ("R2026.02", "Large", "7.1.", "15.1.", "22.1.", "12.2."),
    ("R2026.03.1", "Small", "26.2.", None, "5.3.", "12.3."),
    ("R2026.04.1", "Small", "9.4.", None, "16.4.", "23.4."),
    ("R2026.05.1", "Small", "29.4.", None, "7.5.", "14.5."),
    ("R2026.05", "Large", "12.3.", "23.4.", "30.4.", "21.5."),
    ("R2026.06.1", "Small", "28.5.", None, "11.6.", "18.6."),
    ("R2026.07.1", "Small", "2.7.", None, "9.7.", "16.7."),
    ("R2026.08.1", "Small", "29.7.", None, "6.8.", "13.8."),
    ("R2026.08", "Large", "25.6.", "23.7.", "30.7.", "20.8."),
    ("R2026.09.1", "Small", "27.8.", None, "3.9.", "10.9."),
    ("R2026.10.1", "Small", "23.9.", None, "1.10.", "8.10."),
    ("R2026.11.1", "Small", "21.10.", None, "29.10.", "5.11."),
    ("R2026.11", "Large", "10.9.", "15.10.", "22.10.", "12.11."),
    ("R2026.12.1", "Small", None, None, "18.11.", "3.12."),
    ("R2026.12", "Large", None, None, "19.11.", "9.12."),
]

# (popis, od, do) – "do" None = koniec v kalendári neuvedený
FREEZES = [
    ("Failover test DC1 Kopčianska (DR) – infraštruktúrny a inštalačný freeze", "19.3.", "23.3."),
    ("Failover test DC2 Varšavská (DR) – infraštruktúrny a inštalačný freeze", "24.9.", "28.9."),
    ("Refresh INT", "18.11.", "10.12."),
    ("Infraštruktúrny a inštalačný freeze (koniec neuvedený)", "11.12.", None),
    ("Testy EOY 2026", "11.12.", "23.12."),
]

# Prahy otvorených defektov: severity -> (max pre OK, max pre COK); nad COK = N/A
DEFEKTY = {
    "INT": {"A+": (0, 0), "A": (0, 0), "B": (0, 0), "C": (0, 0)},
    "UAT": {"A+": (0, 0), "A": (0, 0), "B": (5, 7), "C": (10, 12)},
    "LIVE": {"A+": (0, 0), "A": (0, 0), "B": (0, 2), "C": (0, 4)},
}
PORADIE = {"OK": 0, "COK": 1, "N/A": 2}


def datum(text: str | None) -> date | None:
    if text is None:
        return None
    t = text.strip()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", t)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            raise ValueError(f"Neplatný dátum: {text!r}") from None
    m = re.fullmatch(r"(\d{1,2})\.\s*(\d{1,2})\.?\s*(\d{4})?", t)
    if not m:
        raise ValueError(f"Neznámy formát dátumu: {text!r} (použi d.m.rrrr alebo rrrr-mm-dd)")
    rok = int(m.group(3)) if m.group(3) else ROK
    try:
        return date(rok, int(m.group(2)), int(m.group(1)))
    except ValueError:
        raise ValueError(f"Neplatný dátum: {text!r}") from None


def fmt(d: date | None) -> str:
    return f"{d.day}.{d.month}.{d.year}" if d else "neuvedené"


def release(nazov: str):
    for r in RELEASES:
        if r[0].lower() == nazov.lower():
            return r
    raise SystemExit(f"Release {nazov} nie je v kalendári {ROK}. Over názov (napr. R2026.09.1).")


def okno(r, prostredie: str):
    """Vráti (od, do) povolené pre prostredie v danom release, alebo None ak sa nedá určiť."""
    _, typ, first, last, uat, live = r
    first, last, uat, live = datum(first), datum(last), datum(uat), datum(live)
    if typ == "Small":
        return (first, live) if first and live else None
    if prostredie == "INT":
        return (first, last) if first and last else None
    cielovy = uat if prostredie == "UAT" else live
    return (cielovy, cielovy) if cielovy else None


def popis_okna(w) -> str:
    return f"musí byť presne {fmt(w[0])}" if w[0] == w[1] else f"povolené {fmt(w[0])}–{fmt(w[1])}"


def kontrola_roka(d: date) -> bool:
    if d.year != ROK:
        print(f"Upozornenie: kalendár v skripte je len pre rok {ROK} – dátum {fmt(d)} nie je možné overiť.")
        return False
    return True


def freeze_varovania(d: date) -> list[str]:
    out = []
    for popis, od, do in FREEZES:
        od_d = datum(od)
        do_d = datum(do) if do else date(ROK, 12, 31)
        if od_d <= d <= do_d:
            out.append(f"POZOR: {fmt(d)} spadá do obdobia „{popis}“ ({od}–{do or '…'}).")
    return out


def cmd_kalendar(_args) -> int:
    print(f"Release kalendár {ROK}")
    print(f"{'Release':<12} {'Typ':<6} {'First INT':<10} {'Last INT':<9} {'UAT':<7} {'LIVE':<7}")
    for n, t, f, l, u, lv in RELEASES:
        print(f"{n:<12} {t:<6} {f or '-':<10} {l or '-':<9} {u or '-':<7} {lv or '-':<7}")
    print("\nObdobia freeze / obmedzení:")
    for popis, od, do in FREEZES:
        print(f"- {od}–{do or '…'} {popis}")
    return 0


def cmd_okno(args) -> int:
    d = datum(args.datum)
    if not kontrola_roka(d):
        return 0
    env = args.prostredie
    platne, buduce = [], []
    for r in RELEASES:
        w = okno(r, env)
        if not w:
            continue
        if w[0] <= d <= w[1]:
            platne.append((r, w))
        elif w[0] > d:
            buduce.append((r, w))
    print(f"Dátum {fmt(d)} pre prostredie {env}:")
    if platne:
        for r, w in platne:
            print(f"- VYHOVUJE: {r[0]} ({r[1]}) – {popis_okna(w)}")
    else:
        print("- Nespadá do okna žiadneho releasu → CAB automat dá PREAPPROVED s výhradou o nezhode dátumu.")
    for typ in ("Small", "Large"):
        kandidati = sorted((x for x in buduce if x[0][1] == typ), key=lambda x: x[1][0])
        if kandidati:
            r, w = kandidati[0]
            print(f"- Najbližší ďalší {typ} release: {r[0]} – {popis_okna(w)}")
    for v in freeze_varovania(d):
        print(v)
    return 0


def cmd_ir(args) -> int:
    r = release(args.release)
    zadane = {"INT": args.int, "UAT": args.uat, "LIVE": args.live}
    if not any(zadane.values()):
        raise SystemExit("Zadaj aspoň jeden dátum: --int, --uat alebo --live.")
    print(f"Kontrola IR voči {r[0]} ({r[1]} release)")
    chyby, dni, neoverene = [], {}, []
    for env, hodnota in zadane.items():
        if not hodnota:
            print(f"- {env}: na IR neuvedené → Potrebné overiť, či má IR vyplnený termín {env}.")
            neoverene.append(env)
            continue
        d = datum(hodnota)
        if not kontrola_roka(d):
            neoverene.append(env)
            continue
        dni[env] = d
        w = okno(r, env)
        if not w:
            print(f"- {env}: {fmt(d)} – okno sa z kalendára nedá určiť → Potrebné overiť s Release manažérom.")
            neoverene.append(env)
            continue
        pravidlo = popis_okna(w)
        if w[0] <= d <= w[1]:
            print(f"- {env}: {fmt(d)} OK ({pravidlo})")
        else:
            print(f"- {env}: {fmt(d)} MIMO OKNA ({pravidlo})")
            chyby.append(env)
        for v in freeze_varovania(d):
            print(f"  {v}")
    poradie = [dni[e] for e in ("INT", "UAT", "LIVE") if e in dni]
    if poradie != sorted(poradie):
        print("- Upozornenie: dátumy nejdú chronologicky INT ≤ UAT ≤ LIVE → Potrebné overiť.")
    if chyby:
        print(f"\nVýsledok: CAB automat pravdepodobne dá PREAPPROVED s výhradou "
              f"„Dátum na IR sa nezhoduje s dátumami pre INT/UAT/LIVE v Release {r[0]}“ "
              f"→ upraviť dátum na IR alebo kontaktovať Release manažéra.")
    elif neoverene:
        print(f"\nVýsledok: zadané dátumy nie sú mimo okna, ale {', '.join(neoverene)} sa nedá overiť → Potrebné overiť.")
    else:
        print("\nVýsledok: dátumy na IR sú v okne releasu.")
    return 0


def cmd_testy(args) -> int:
    etapa = args.etapa.upper()
    limity = DEFEKTY[etapa]
    pocty = {"A+": args.a_plus, "A": args.a, "B": args.b, "C": args.c}
    vysledky, dovody = [], []
    print(f"Prechod do Ready for {etapa} – otvorené defekty:")
    for sev, pocet in pocty.items():
        if pocet is None:
            print(f"- {sev}: neuvedené → Potrebné overiť (Recalculate Defect Count)")
            continue
        ok_max, cok_max = limity[sev]
        if pocet <= ok_max:
            v = "OK"
        elif pocet <= cok_max:
            v = "COK"
        else:
            v = "N/A"
        vysledky.append(v)
        print(f"- {sev}: {pocet} → {v} (OK ≤ {ok_max}, COK ≤ {cok_max})")
        if v != "OK":
            dovody.append(f"defekty {sev} = {pocet}")
    if args.tc_total is not None and args.tc_pass is not None:
        if args.tc_total == 0:
            print("- Test case-y: total = 0 → Potrebné overiť, či sú TC evidované.")
        else:
            pomer = args.tc_pass / args.tc_total * 100
            v = "OK" if pomer >= 95 else "COK" if pomer >= 85 else "N/A"
            vysledky.append(v)
            print(f"- Test case-y: {args.tc_pass}/{args.tc_total} = {pomer:.1f} % → {v} (OK ≥ 95 %, COK ≥ 85 %)")
            if v != "OK":
                dovody.append(f"úspešnosť TC {pomer:.1f} %")
    elif etapa == "INT":
        print("- Test case-y: pri vstupe do INT sa výsledky testov spravidla nehodnotia.")
    else:
        zdroj = "INT" if etapa == "UAT" else "UAT"
        print(f"- Test case-y: neuvedené → Potrebné overiť počty TC z {zdroj} (záložka Testing).")
    if etapa == "INT":
        print("  Pozn.: postimplementačné DE s fixmi defektov dostanú výhradu „Neštandardný stav defektov“ → Release manažér.")
    if vysledky:
        celkovo = max(vysledky, key=lambda x: PORADIE[x])
        dovod = f" – {', '.join(dovody)}" if dovody else ""
        print(f"\nČiastkový výsledok (testy a defekty): {celkovo}{dovod}")
        print("CAB automat hodnotí aj flagy, AC, akceptáciu, dokumentáciu a dátumy na IR.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Predkontrola pravidiel CAB automatu (eGOV, 2026).")
    sub = ap.add_subparsers(dest="prikaz", required=True)

    sub.add_parser("kalendar", help="vypísať release kalendár a freeze").set_defaults(fn=cmd_kalendar)

    p = sub.add_parser("okno", help="ktorý release povoľuje daný dátum")
    p.add_argument("datum")
    p.add_argument("--prostredie", default="INT", choices=["INT", "UAT", "LIVE"])
    p.set_defaults(fn=cmd_okno)

    p = sub.add_parser("ir", help="overiť dátumy na IR voči releasu")
    p.add_argument("release")
    p.add_argument("--int")
    p.add_argument("--uat")
    p.add_argument("--live")
    p.set_defaults(fn=cmd_ir)

    p = sub.add_parser("testy", help="vyhodnotiť defekty a test case-y")
    p.add_argument("etapa", choices=["INT", "UAT", "LIVE", "int", "uat", "live"])
    p.add_argument("--a-plus", type=int)
    p.add_argument("--a", type=int)
    p.add_argument("--b", type=int)
    p.add_argument("--c", type=int)
    p.add_argument("--tc-total", type=int)
    p.add_argument("--tc-pass", type=int)
    p.set_defaults(fn=cmd_testy)

    args = ap.parse_args()
    try:
        return args.fn(args)
    except ValueError as e:
        print(e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
