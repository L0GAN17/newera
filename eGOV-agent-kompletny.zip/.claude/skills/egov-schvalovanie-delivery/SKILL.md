---
name: egov-schvalovanie-delivery
description: Vyhodnotí delivery požiadavku eGOV v JIRA (DELIVERMGT) voči schvaľovaciemu procesu – čo chýba do Ready for INT/UAT/LIVE a Approved, ako dopadne CAB automat (OK, COK, PREAPPROVED, N/A), či dátumy na IR sedia s oknom releasu, čo znamenajú výhrady v CAB Status Notes a chybové hlášky pri tranzíciách; pripraví aj offline CAB mail. Použi vždy pri screenshote alebo texte z JIRA delivery, IR, capability či Big Epicu, pri otázke „čo mám spraviť, aby som to prepol / schválil", pri CAB, ARB, flagoch SECURITY/IARCH/GDPR, akceptačnom protokole, prevádzkovej dokumentácii alebo release kalendári.
---

# Schvaľovanie delivery eGOV (CAB automat)

Cieľ: aby delivery manager vedel **presne, čo chýba a v akom poradí to doplniť**, a aby
ho CAB automat neprekvapil výsledkom N/A alebo PREAPPROVED.

## Podklady

- `references/cab-pravidla.md` – podmienky pre jednotlivé stavy, výsledky automatu,
  prahy defektov a testov, akceptácia.
- `references/release-kalendar-2026.md` – okná releasov a obdobia freeze.
- `references/jira-poucenia.md` – pasce z praxe: chybové hlášky, smery linkov,
  doťahovanie flagov.
- `assets/offline-cab-mail.md` – šablóna mailu pre offline CAB.
- `scripts/cab_kontrola.py` – výpočtová kontrola dátumov na IR a prahov.

Cesty sú relatívne k priečinku tohto skillu.

## Postup

1. **Identifikuj delivery:** kľúč (DELIVERMGT-…), Delivery type (Integrational /
   Non Integrational), aktuálny stav, cieľový prechod, release.
2. **Prečítaj všetko, čo je v podklade:**
   - *General:* CAB Status, **CAB Status Notes** (výhrady), Checklist Result.
   - *INT Criteria:* ARB, SECURITY, GDPR, IARCH, ITOPS Statement, Plan of Delivery,
     Test Statement.
   - *Testing:* otvorené defekty A+/A/B/C, test case-y (Total/Pass/Fail/Other)
     z INT a UAT, Test Strategy.
   - *Acceptance Criteria:* sub-tasky AC DOC / AC TEST a ich stav, linky na
     detailné analýzy (hodnota „undefined" = chýbajúci link).
   - *Edit IRs:* IR, jej stav, Term INT/UAT/LIVE, Included Features.
   - *Issue Links:* `delivers` → capabilities, `relates to` → Theme/Big Epic.
   - *Capability / Big Epic:* ARB Design Review, Infrastructure, Security, IArch,
     GDPR, Cloud Impact.
3. **Porovnaj s podmienkami** cieľového stavu v `references/cab-pravidla.md`.
4. **Spusti výpočtové kontroly**, ak máš čísla alebo dátumy:
   ```
   python scripts/cab_kontrola.py ir R2026.09.1 --int 27.8. --uat 3.9. --live 10.9.
   python scripts/cab_kontrola.py okno 25.5.2026 --prostredie INT
   python scripts/cab_kontrola.py testy UAT --a-plus 1 --a 0 --b 4 --c 1 --tc-total 16 --tc-pass 11
   ```
5. **Porovnaj s pascami** v `references/jira-poucenia.md` – najmä pri chybovej hláške
   alebo nečakanej výhrade.
6. **Vráť výstup** podľa formátu nižšie.

## Formát výstupu

```
# DELIVERMGT-… → <cieľový stav>

**Predpokladaný výsledok CAB automatu:** OK / COK / PREAPPROVED / N/A – jedna veta prečo.

| Podmienka | Stav | Kde v JIRA | Čo spraviť |
|---|---|---|---|

## Čo spraviť teraz
1. … (zoradené: najprv to, čo blokuje)

## Potrebné overiť
- …
```

- Stav podmienky: ✅ splnené · ❌ chýba · ⚠️ nejasné · `Nenájdené v podklade`.
- Čo na screenshote nie je, **nepredpokladaj ako splnené** – uveď „over v JIRA
  na záložke …".
- Ak sa podmienka rieši cez iného človeka, ponúkni jednou vetou Teams správu
  (skill `egov-komunikacia`).

## Pravidlá vyhodnotenia

- **PREAPPROVED** vždy znamená kontaktovať Release manažéra – aj keď výhrady opravíš.
- **N/A** znamená odstrániť výhrady a nechať automat vyhodnotiť znova, alebo
  žiadať výnimku od CAB.
- **Integrational vs. Non Integrational:** ARB je povinné pri integračnej zmene;
  akceptačné kritériá a protokol sa pri neintegračnej spravidla nevyžadujú.
  Neintegračná delivery s ARB flagom iným ako NQ ide do PREAPPROVED.
- **Flagy SECURITY/IARCH/GDPR** sa na delivery doťahujú z capabilities až pri
  kliknutí na tranzíciu a berie sa najhoršia hodnota – pozri `jira-poucenia.md`.
- **Dátum na IR** mimo okna releasu = PREAPPROVED s výhradou o nezhode dátumu.
  Vždy over skriptom.
- **Obdobia freeze** (DR testy, refresh INT, koniec roka) – upozorni, ak plánovaný
  dátum inštalácie do nich padne.
- **Otvorený defekt, ktorý biznis nepovažuje za show stopper,** neodstráni výhradu
  automatu – rieši sa cez Release manažéra alebo offline CAB so stanoviskom biznisu.

## Offline CAB

Keď treba schválenie mimo automatu (PREAPPROVED, výnimka, doschválenie IR pridanej
po schválení), priprav mail podľa `assets/offline-cab-mail.md`:

- adresát `release_managers@tatrabanka.sk`, formálny tón,
- link na delivery, link na IR (ak ide o doschválenie IR), prostredie, krátky popis
  čo sa inštaluje, plánovaný dátum inštalácie,
- pri otvorenom defekte: severity, dopad a stanovisko biznisu citované presne.

Linky, čísla IR a dátumy, ktoré nemáš, nechaj ako `[doplniť]` – nevymýšľaj ich.
Pred odoslaním upozorni na kontrolu dátumu voči oknu releasu.
