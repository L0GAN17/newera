# Šablóna – offline CAB

Offline CAB má formu e-mailu na **release_managers@tatrabanka.sk**. Tón je formálny.

## Povinný obsah

1. Link na delivery z JIRA
2. Link na IR z JIRA – ak ide o doschválenie IR pridanej do delivery po jej schválení
3. Prostredie, do ktorého sa bude inštalovať
4. Krátky popis delivery alebo doplnenej IR (čo sa inštaluje alebo pridáva)
5. Dátum plánovanej inštalácie

Pri otvorenom defekte navyše: severity, stručný dopad a presná citácia stanoviska
biznisu, prečo defekt nebráni inštalácii.

## Šablóna

```
Predmet: Offline CAB – žiadosť o schválenie DELIVERMGT-[číslo] do [INT/UAT/LIVE]

Dobrý deň,

formou offline CAB žiadam o schválenie inštalácie nižšie uvedenej delivery
do prostredia [INT/UAT/LIVE].

Delivery: DELIVERMGT-[číslo] – [názov delivery]
Link na delivery: [doplniť]

IR: [IR-číslo]                        ← len pri doschválení pridanej IR
Link na IR: [doplniť]

Prostredie: [INT/UAT/LIVE]
Plánovaný dátum inštalácie: [d.m.rrrr]

Popis:
[1–3 vety: čo delivery alebo doplnená IR obsahuje.]

Stav testovania:                      ← len ak je otvorený defekt
Otvorený zostáva [počet] defekt severity [A/B/C] týkajúci sa [téma].
Biznis zadávateľ defektu k nemu uviedol: „[presná citácia]".

Prosím o posúdenie a schválenie delivery do stavu APPROVED [INT/UAT/LIVE].

Ďakujem,
[meno]
Delivery Manager – eGOV
```

## Pred odoslaním over

- Dátum inštalácie je v okne releasu (`python scripts/cab_kontrola.py ir …`).
- Všetky polia `[doplniť]` sú vyplnené – nič z nich nevymýšľaj.
- Ak IR bola súčasťou delivery už pri predchádzajúcom schválení, časť o IR vynechaj.
