---
name: egov-komunikacia
description: Pripraví texty na odoslanie alebo prečítanie k projektu eGOV – Teams správy kolegom a dodávateľovi (tykanie), správy do Teams skupiny eGOV, standup, planning, status pre nadriadeného či stakeholderov, týždenný status na Epic, jednovetový status, JIRA komentár, mail dodávateľovi so závermi, úvod na stretnutie a hovorové odprezentovanie statusu. Použi vždy, keď používateľ chce „správu", „status", „čo mám povedať na standupe", „napíš to neformálnejšie / kratšie / v bodoch" alebo text, ktorý pošle či prečíta.
---

# Komunikácia – eGOV

Texty píše delivery manager kolegom, ktorých dobre pozná. Musia znieť ako od človeka:
krátko, prirodzenou slovenčinou, s konkrétnou požiadavkou. Najčastejšia spätná väzba
na prvú verziu je „kratšie, neformálnejšie, v bodoch" – preto začni rovno tak.

## Tón podľa kanála

| Typ | Oslovenie a tón | Dĺžka |
|---|---|---|
| Teams správa kolegovi (aj DISIG, DMS) | „Ahoj Meno," – tykanie, neformálne | do ~10 riadkov |
| Teams skupina eGOV (biznis) | „Ahojte," – neformálne, vecne | do ~10 riadkov |
| Mail dodávateľovi | „Ahojte," – neformálne, štruktúrované | krátko, očíslované body |
| Offline CAB, oficiálny mail | „Dobrý deň," – formálne | podľa šablóny v `egov-schvalovanie-delivery` |
| JIRA komentár | vecne, bez oslovenia | 2–5 viet |
| Standup, planning, text na prečítanie | hovorovo, v bodoch | podľa typu nižšie |

## Pravidlá písania

- Jedna správa = jeden adresát a jeden účel. Viac adresátov → viac správ.
- Kontext jednou vetou, potom konkrétna požiadavka. Pri 2+ otázkach ich očísluj.
- Uveď, čo potrebuješ a dokedy – ak termín zaznel. Nevymýšľaj ho.
- Len fakty z podkladu. Formuláciu môžeš meniť, obsah nie.
- Text na odoslanie daj do bloku kódu, aby sa dal skopírovať.
- Emoji len striedmo (0–3) a len v Teams skupine.

**Vyhýbaj sa frázam, ktoré znejú ako AI alebo úradne:** „dúfam, že sa máš dobre",
„rád by som ťa informoval", „neváhaj ma kontaktovať", „v nadväznosti na vyššie
uvedené", „dovoľ mi zhrnúť", „je dôležité poznamenať". Namiesto nich: „dám vedieť",
„hodím do chatu", „loptička je na našej strane", „vieš sa na to pozrieť?".

## Typy výstupov

### Teams správa kolegovi
```
Ahoj Matej, k [téma] – [jedna veta kontextu].

1. [konkrétna otázka / požiadavka]
2. [konkrétna otázka / požiadavka]

Vďaka!
```

### Správa do Teams skupiny eGOV
Novinka → čo to znamená pre biznis → čo od nich treba. Pri nasadení: verzia,
prostredie, na akú delivery zadávať defekty, odkazy na návody (`[link]`, ak chýbajú).

### Standup
- Na požiadanie „dve vety" – presne dve vety, len novinky, hovorovo.
- Na požiadanie „v bodoch" – 3–5 bodov na prečítanie.
- Varianta Včera / Dnes / Blokery, ak ju používateľ chce.

### Planning (prezentácia subtaskov)
Po bodoch, neformálne, jeden riadok na subtask; na konci jedna veta o hlavnom riziku.

### Status pre nadriadeného / stakeholderov
Rozdeľ podľa dodávok (Q2, Q3…). Pri každej **Kde sme** a **Čo nás brzdí / riziká**.
Krátke body, písané ako človek. Žiadne fakty, ktoré nezazneli na stretnutiach.

### Status na Epic (týždenný Epic meeting)
Nový záznam ide navrch zoznamu Status Notes vo formáte:
```
D.M <stav – najviac dve vety>
```
Príklad: `22.7 čakáme za uvoľnením prostredia`. Na požiadanie pridaj dlhšiu
hovorovú verziu na odprezentovanie.

### Jednovetový status
Jedna veta: stav + na čom to stojí + čo nasleduje.

### JIRA komentár
Vecne pre audit trail: čo sa zistilo alebo rozhodlo, kto to potvrdil, kedy, dopad
na delivery. Napr. potvrdenie flagu NQ IT architektom.

### Mail dodávateľovi so závermi
Po internom stretnutí: čo sme dohodli, čo od nich potrebujeme, čo sa ich netýka
(interné témy ako financovanie vynechaj, ak nie je rozhodnuté). Očíslované body.

### Úvod na stretnutie (predslov)
4–6 viet na prečítanie: prečo sme sa stretli, čo už vieme, čo chceme dnes
dohodnúť, prečo je to dôležité. Tykanie, ak sa účastníci poznajú.

### Hovorové odprezentovanie statusu
Súvislý text na prečítanie po odsekoch, prirodzený tok („Najprv…", „Potom…",
„Hlavné riziko je…"). Na požiadanie skráť do bodov.

## Úpravy existujúceho textu

Pri pokynoch „neformálnejšie", „kratšie", „v bodoch", „ako človek, nie AI" meň len
tón a formu – fakty, mená, čísla a termíny zostávajú. Ak pokyn odkazuje na vetu,
ktorú nevidíš, uprav najpravdepodobnejšiu a jednou vetou napíš, ktorú si vybral.
