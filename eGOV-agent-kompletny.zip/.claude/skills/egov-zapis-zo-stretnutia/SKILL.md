---
name: egov-zapis-zo-stretnutia
description: Spracuje prepis, poznámky alebo nahrávku zo stretnutia k eGOV (status s DISIG, interný biznis status, technické stretnutie s DMS) do overeného formálneho zápisu v štýle Plaud Note Pro – zhrnutie, témy, rozhodnutia, úlohy s prostredím INT/UAT/LIVE, riziká, otvorené body, Teams správy pre vlastníkov úloh a záver. Použi vždy, keď príde VTT/TXT prepis alebo poznámky zo stretnutia k eGOV, aj keď používateľ nenapíše slovo „zápis".
---

# Zápis zo stretnutia – eGOV

Zápis číta interný tím, biznis vlastníčka aj dodávateľ DISIG. Musí sa dať vložiť do
mailu, Confluence, JIRA alebo Teams bez úprav a nesmie obsahovať nič, čo na stretnutí
nezaznelo – na zápise sa neskôr stavajú rozhodnutia aj fakturácia.

## Postup

1. **Priprav prepis.** Ak je vstup WEBVTT (`.vtt`, ale aj `.txt` či `.md` so začiatkom
   `WEBVTT`), spusti:
   ```
   python scripts/vtt_na_text.py <súbor> --suhrn   # hovorcovia a rozsah
   python scripts/vtt_na_text.py <súbor>           # čitateľný text
   ```
   Cesta k skriptu je relatívna k priečinku tohto skillu. Prečítaj celý prepis,
   nielen začiatok.
2. **Urči účastníkov a typ stretnutia.** Hovorca s „(… Guest)" je externý – spravidla
   DISIG. Ak niekto zo zvyčajných účastníkov chýbal a zaznelo to, uveď to. Delivery
   manager nemusí byť prítomný – aj to uveď.
3. **Oprav chyby prepisu** podľa `references/prepisove-chyby.md`. Jednoznačnú opravu
   urob ticho, nejednoznačnú označ `Možná interpretácia`.
4. **Roztrieď obsah** na rozhodnutia, úlohy, riziká, otvorené body a informácie.
5. **Zostav zápis** podľa šablóny nižšie. Ak používateľ v prompte dal vlastnú
   štruktúru alebo číslovanie (napr. len sekcie 2–7, 8 a 10), drž sa jej presne.
6. **Skontroluj** výstup podľa kontrolného zoznamu na konci.

## Šablóna

```
# Zápis zo stretnutia – eGOV

*(Účastníci: … Neprítomní: … ak zaznelo)*

[Upozornenie na nízku kvalitu prepisu – len ak je prepis výrazne fragmentovaný.]

## 1. Názov stretnutia          ← len ak ho prompt žiada
## 2. Stručné zhrnutie meetingu
## 3. Hlavné diskutované témy
## 4. Prijaté rozhodnutia
## 5. Akčné úlohy / Action items
## 6. Riziká, blokery a závislosti
## 7. Otvorené body
## 8. Otázky a Teams správy pre kolegov
## Manažérsky súhrn / Technický súhrn   ← len ak ich prompt žiada
## 10. Finálny záver

*Poznámka k zápisu: …*
```

### 2. Stručné zhrnutie
5–8 bodov: cieľ stretnutia, hlavné témy, výsledok. Dĺžka sa však riadi obsahom –
krátke stretnutie o jednej veci nemá osem bodov. Nedopĺňaj bod len kvôli počtu.

### 3. Hlavné diskutované témy
Pre každú tému samostatná podsekcia `### 3.x Názov`:
- **Čo sa riešilo**
- **Vyjadrovali sa** – len ak je to z prepisu zrejmé
- **Dôležité zistenia** – fakty, čísla, termíny, ako zazneli
- **Otvorené otázky** – nejasnosti a nerozhodnuté veci
- **Navrhované riešenie / ďalší postup**

### 4. Prijaté rozhodnutia
| Rozhodnutie | Kontext | Zodpovedná osoba/tím | Dopad | Poznámka |
|---|---|---|---|---|

Len to, čo sa naozaj uzavrelo. Diskusia bez záveru patrí do otvorených bodov.

### 5. Akčné úlohy
| Úloha | Prostredie | Zodpovedná osoba/tím | Termín | Priorita | Kontext |
|---|---|---|---|---|---|

- Úloha začína slovesom („Poslať cenovú ponuku…", nie „cenová ponuka").
- Dve úlohy nikdy nezlučuj do jednej, ani keď súvisia.
- Vlastník alebo termín nezaznel → `Neuvedené v prepise`.
- Termín píš tak, ako zaznel („zajtra 10:00–10:30", „do konca týždňa"). Prepočet na
  dátum len ak poznáš dátum stretnutia – a označ ho `Možná interpretácia`.
  Nikdy nemeň termín na „čo najskôr", ak tak nezaznel.
- Prostredie: `INT`, `UAT`, `LIVE`, `neurčené`, alebo `–`, ak sa úlohy netýka.
  Úlohu pre viac prostredí rozpíš na riadky.
- Priorita: ak nezaznela, odvoď ju z dopadu (blokuje LIVE/UAT/CAB = Vysoká;
  technické a obchodné témy = Stredná; informatívne = Nízka).

### 6. Riziká, blokery a závislosti
| Riziko / blocker | Popis | Dopad | Navrhované riešenie | Vlastník |
|---|---|---|---|---|

Najmä to, čo ohrozuje termín, dodávku, testovanie, nasadenie, schválenie alebo biznis
proces (externé závislosti, dovolenky, chýbajúce financovanie, nefunkčné nástroje).

### 7. Otvorené body
Otázky bez odpovede, veci na overenie, závislosti na iných tímoch, body bez
rozhodnutia. Sem patrí aj každé `neurčené` prostredie, chýbajúci termín a dátum
stretnutia, ak nezaznel.

### 8. Otázky a Teams správy pre kolegov
- Jedna správa na človeka alebo tím, ktorého sa týka úloha či otvorená téma.
- Tykanie, neformálne, krátko; v bloku kódu, aby sa dala skopírovať.
- Konkrétne otázky, pri viacerých očíslované. Len o veciach zo zápisu.
- Ak je vlastníkom úlohy sám delivery manager, napíš mu pripomienku, nie správu.
- Nadpis: `### 8.x Meno – téma`.

### 10. Finálny záver
Tri krátke bloky: **Čo bolo dohodnuté** · **Čo treba spraviť ďalej** · **Kto má
pokračovať v riešení**.

### Poznámka k zápisu
Kurzívou na konci: ktoré skomolené výrazy boli interpretované (napr. „kvet dvojka" =
Q2), či nezaznel dátum stretnutia, kto sa nezúčastnil.

## Štýl

- Formálne a vecne. Žiadne hodnotiace prídavné mená („konštruktívna debata").
  Vecné prídavné mená sú v poriadku („samostatná dodávka", „trojminútový timeout").
- Mená osôb, systémov a kľúče z JIRA ponechaj tak, ako zazneli – opravuj len
  zjavné chyby rozpoznávania reči.
- Nezmäkčuj nezhodu. Ak sa účastníci nezhodli alebo niekto vyjadril nespokojnosť,
  zapíš to vecne a nevyriešené časti daj do otvorených bodov.
- Ak je prepis taký útržkovitý, že sa z neho nedá spraviť zápis, povedz to a vypíš,
  čo by si potreboval. Zápis z ničoho nevyrábaj.

## Kontrolný zoznam

- [ ] Každé tvrdenie má oporu v prepise, alebo je označené značkou.
- [ ] Žiadne rozhodnutie nevzniklo z diskusie bez záveru.
- [ ] Každá úloha má vlastníka, termín a prostredie – alebo príslušnú značku.
- [ ] Všetky `neurčené` a `Neuvedené v prepise` položky sú aj v otvorených bodoch.
- [ ] Sekcia 8 pokrýva všetkých vlastníkov úloh okrem delivery managera.
- [ ] Poznámka k zápisu uvádza interpretácie a chýbajúci dátum.

## Nadväzujúce požiadavky

Po zápise používateľ často chce jeho kratšiu formu – veľmi krátky súhrn v bodoch,
dve vety na standup, mail dodávateľovi so závermi alebo text na prečítanie na
internom stretnutí. Tie rieš skillom `egov-komunikacia`, zo zápisu, bez nových faktov.
