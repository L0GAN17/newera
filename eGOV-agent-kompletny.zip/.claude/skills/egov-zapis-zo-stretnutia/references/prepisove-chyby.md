# Časté chyby rozpoznávania reči v prepisoch eGOV

Zoznam vznikol z doterajších Teams prepisov. Opravuj len v kontexte – ak môže mať
výraz viac významov, použi značku `Možná interpretácia`. Nové zistenia dopĺňaj sem.

## Projektové pojmy

| V prepise | Pravdepodobne | Poznámka |
|---|---|---|
| kvet, kvet dvojka / trojka / štvorka, vetrovka, tuk vetrovka, rojková, kw | Q (kvartál): Q2 / Q3 / Q4 | „kvet dvojka" = Q2 dodávka |
| d mäsko, daj mesko, d mestsko, d mestská, dámska, démonská, nemecko, t mesko, d msg, dfsg | DMS | pri „dfsg" over kontext |
| dodajme sk, téma sk, dpfko | DMS alebo Slovensko.sk | vždy `Možná interpretácia` |
| úpn, úpvs sk, df sk | ÚPVS / Slovensko.sk | |
| úrad, úvrate, na vate, navrate, do úľa tu, úctu | UAT | len ak ide o prostredie |
| ind, inte, ince | INT | |
| laiwu, ľad, ľadovej, leifheit, life, lajv | LIVE | „do živej", „živé" = LIVE |
| gire, džura, číra, diera, džezva | JIRA | |
| z hry (admini z hry) | admini JIRA | `Možná interpretácia` |
| bicykel, disi guo, dánsko, disk, design | DISIG | |
| men deje, mandre, mendia, mandátov, medaily, mendeza, mesiace | MD (človekodne) | „4 mesiace" môže byť „4 MD" |
| ekológ, ekolky | eKolok | |
| depa nizácia, pán izácia, kde pani záciu | depanelizácia | |
| generál dog, generál doxx | GeneralDoc | |
| dog typ | docType | |
| rik vesta | request | |
| téma out | timeout | |
| breg, záber | subreg | `Možná interpretácia` |
| kvit n cií | kvitancie | |
| replík, replik | IS REPLIK / repliky | |
| štyri oči | schválenie druhou osobou | |
| sedačka | sadzba alebo výkaz | `Nejasné z prepisu` – over kontext |

## Mená

| V prepise | Pravdepodobne |
|---|---|
| ježko, jožka | Jožko (Jozef Sedlák) |
| lyžička, husička, holička, mužíček, žička, ružička, mliečko | Peťo Hužička (DMS) – `Možná interpretácia` |
| hĺbková, hubková | Zuzka Hupková |
| mierka | Mirka (Miroslava Michňová) |
| máte, maťo (oslovenie) | Matej (Jurík) |
| jančo, janči | Ján Privara (DMS) |

## Ako s tým pracovať

- Opravu, ktorá je z kontextu jednoznačná, urob ticho.
- Nejednoznačnú opravu označ priamo v texte: „…(*Možná interpretácia: DMS*)".
- Na konci zápisu vymenuj interpretované výrazy v Poznámke k zápisu.
- Pasáž, ktorej sa nedá rozumieť ani s pomocou kontextu, označ `Nejasné z prepisu`
  a nedopĺňaj domnienky.
