#!/usr/bin/env python3
"""Prevod Teams prepisu (WEBVTT) na čitateľný text pre zápis zo stretnutia.

Použitie:
  python vtt_na_text.py prepis.vtt                  # čitateľný text na výstup
  python vtt_na_text.py prepis.vtt --casy           # s časom začiatku repliky
  python vtt_na_text.py prepis.vtt --suhrn          # len hovorcovia a štatistika
  python vtt_na_text.py prepis.vtt -o prepis.txt    # uloženie do súboru

Funguje aj pre .txt / .md súbory, ktoré obsahujú WEBVTT (Teams ich tak niekedy
exportuje). Nevyžaduje žiadne externé knižnice.

Čo robí:
- odstráni identifikátory cue a časové značky,
- dekóduje HTML entity (&#193; -> Á),
- spojí po sebe idúce repliky toho istého hovorcu,
- znormalizuje mená („Lukáš ŠINAĽ" -> „Lukáš Šinaľ", „(TBSK Guest)" -> externý).
Obsah replík nemení – opravu chýb rozpoznávania reči robí až zápis.
"""
import argparse
import html
import re
import sys
from pathlib import Path

TIMING_RE = re.compile(r"^\s*((?:\d{1,2}:)?\d{2}:\d{2})[.,]\d{1,3}\s*-->")
VOICE_RE = re.compile(r"<v\s+([^>]+)>(.*?)(?:</v>|$)", re.S)
TAG_RE = re.compile(r"</?[^>]+>")
GUEST_RE = re.compile(r"\s*\(([^)]*guest[^)]*)\)\s*$", re.I)

NEZNAMY = "Neznámy hovorca"


def normalizuj_meno(raw: str) -> tuple[str, bool]:
    """Vráti (meno, je_externy)."""
    meno = html.unescape(raw).strip()
    externy = bool(GUEST_RE.search(meno))
    meno = GUEST_RE.sub("", meno)
    casti = []
    for cast in meno.split():
        if len(cast) > 1 and cast.isupper():
            cast = "-".join(s.capitalize() for s in cast.split("-"))
        casti.append(cast)
    return " ".join(casti) or NEZNAMY, externy


def vycisti(text: str) -> str:
    text = html.unescape(text)
    text = TAG_RE.sub("", text)
    return re.sub(r"\s+", " ", text).strip()


def parsuj(obsah: str) -> list[dict]:
    obsah = obsah.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    segmenty = []
    for blok in re.split(r"\n\s*\n", obsah):
        riadky = [r for r in blok.split("\n") if r.strip()]
        if not riadky:
            continue
        prvy = riadky[0].strip()
        if prvy.upper().startswith("WEBVTT") or prvy.startswith("NOTE"):
            continue
        cas = None
        telo = []
        for riadok in riadky:
            m = TIMING_RE.match(riadok)
            if m:
                cas = m.group(1)
                continue
            if cas is None:  # identifikátor cue pred časovou značkou
                continue
            telo.append(riadok.strip())
        if not telo:
            continue
        spojene = " ".join(telo)
        hlasy = VOICE_RE.findall(spojene)
        if hlasy:
            for hovorca, text in hlasy:
                text = vycisti(text)
                if text:
                    segmenty.append({"cas": cas, "hovorca": hovorca, "text": text})
        else:
            text = vycisti(spojene)
            if text:
                segmenty.append({"cas": cas, "hovorca": None, "text": text})
    return segmenty


def zluc(segmenty: list[dict]) -> tuple[list[dict], dict]:
    repliky, hovorcovia = [], {}
    predosly = None
    for seg in segmenty:
        if seg["hovorca"] is None:
            meno, externy = (predosly or NEZNAMY), False
        else:
            meno, externy = normalizuj_meno(seg["hovorca"])
        info = hovorcovia.setdefault(meno, {"externy": False, "repliky": 0, "slova": 0})
        info["externy"] = info["externy"] or externy
        info["slova"] += len(seg["text"].split())
        if repliky and repliky[-1]["hovorca"] == meno:
            repliky[-1]["text"] += " " + seg["text"]
        else:
            repliky.append({"cas": seg["cas"], "hovorca": meno, "text": seg["text"]})
            info["repliky"] += 1
        predosly = meno
    return repliky, hovorcovia


def formatuj_cas(cas: str | None) -> str:
    if not cas:
        return "--:--:--"
    return cas if cas.count(":") == 2 else "00:" + cas


def main() -> int:
    ap = argparse.ArgumentParser(description="Prevod Teams WEBVTT prepisu na čitateľný text.")
    ap.add_argument("subor", help="cesta k .vtt / .txt / .md prepisu")
    ap.add_argument("--casy", action="store_true", help="pridať čas začiatku repliky")
    ap.add_argument("--suhrn", action="store_true", help="vypísať len hovorcov a štatistiku")
    ap.add_argument("-o", "--vystup", help="uložiť výsledok do súboru")
    args = ap.parse_args()

    cesta = Path(args.subor)
    obsah = cesta.read_text(encoding="utf-8", errors="replace")
    segmenty = parsuj(obsah)
    if not segmenty:
        print("Súbor nevyzerá ako WEBVTT prepis – nenašiel som žiadne repliky.", file=sys.stderr)
        return 1

    repliky, hovorcovia = zluc(segmenty)
    zaciatok = formatuj_cas(segmenty[0]["cas"])
    koniec = formatuj_cas(segmenty[-1]["cas"])

    vystup = [f"# Prepis: {cesta.name}", f"Rozsah: {zaciatok} – {koniec}", "Hovorcovia:"]
    for meno, info in sorted(hovorcovia.items(), key=lambda x: -x[1]["slova"]):
        znacka = " (externý – Guest)" if info["externy"] else ""
        vystup.append(f"- {meno}{znacka}: {info['repliky']} replík, {info['slova']} slov")

    if not args.suhrn:
        vystup.append("")
        for r in repliky:
            prefix = f"[{formatuj_cas(r['cas'])}] " if args.casy else ""
            vystup.append(f"{prefix}{r['hovorca']}: {r['text']}")

    text = "\n".join(vystup) + "\n"
    if args.vystup:
        Path(args.vystup).write_text(text, encoding="utf-8")
        print(f"Uložené: {args.vystup} ({len(repliky)} replík)")
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
