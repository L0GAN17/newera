---
name: zapis-z-porady
description: Z prepisu, poznámok alebo nahrávky spraví zápis, zoznam úloh s termínmi a hotový mail účastníkom. Použi vždy, keď dodám prepis stretnutia, hovoru alebo poznámky z porady.
---

# Zápis z porady

## Kedy tento skill použiť

Používateľ dodá prepis stretnutia, poznámky, prepis hovoru alebo text z nahrávky
a chce z toho zápis. Spúšťacie vety: „zápis z porady", „spracuj tento prepis",
„čo sme sa dohodli", „vytiahni úlohy", „poznámky zo stretnutia".

Funguje na akýkoľvek vstup: čistý prepis, surové poznámky, aj útržky.

## Železné pravidlo

**Nevymýšľaj nič, čo v podklade nie je.**

To platí najmä pre:
- termíny — ak nezaznel, napíš `neurčené`
- zodpovedné osoby — ak nezaznelo meno, napíš `nepridelené`
- rozhodnutia — ak sa diskutovalo, ale nerozhodlo, patrí to medzi otvorené otázky

Mená píš presne tak, ako sú v podklade. Neprekladaj ich, neopravuj, nedopĺňaj
priezviská.

## Postup

1. Prečítaj celý podklad. Zisti, koľko ľudí sa zúčastnilo a kto hovorí.
2. Rozdeľ obsah na: rozhodnutia · úlohy · otvorené otázky · informácie.
3. Pre každú úlohu nájdi zodpovedného a termín. Ak chýbajú, označ ich.
4. Zostav výstup podľa šablóny nižšie.
5. Napíš mail účastníkom.

## Výstup

### 1. Zhrnutie
Čo bolo cieľom stretnutia a s čím sa skončilo. Bez úvodu, bez záveru.

**Dĺžka sa riadi podkladom, nie kvótou.** Krátka porada o jednej veci má zhrnutie
na jednu vetu. Dvojhodinová o piatich témach má päť. **Nikdy nedopĺňaj vetu len
preto, aby zhrnutie vyzeralo dlhšie** — každá veta navyše by musela obsahovať
niečo, čo v podklade nie je, a to je presne to, čo tento skill nesmie.

### 2. Rozhodnutia
```
- [Čo sa rozhodlo] — rozhodol: [kto]
```
Len veci, ktoré sa naozaj uzavreli. Ak sa nerozhodlo nič, napíš
`Na tomto stretnutí nepadlo žiadne rozhodnutie.` a pokračuj.

### 3. Úlohy

| # | Úloha | Kto | Do kedy | Závisí od |
|---|---|---|---|---|

Úloha začína slovesom. „Poslať cenník klientovi", nie „cenník".
Ak úloha závisí od inej, uveď jej číslo. Inak pomlčka.

### 4. Otvorené otázky
Očíslovaný zoznam. Ku každej pridaj, kto ju má uzavrieť, ak to zaznelo.
Sem patria aj všetky `neurčené` termíny a `nepridelené` úlohy.

### 5. Mail účastníkom
Hotový text na odoslanie. Predmet + telo. Maximálne 200 slov.
Štruktúra: jedna veta zhrnutia → rozhodnutia → tabuľka úloh → čo potrebujem od
vás do kedy. Bez pozdravných fráz typu „dúfam, že sa máte dobre".

### 6. Čo v podklade chýbalo
Krátky zoznam. Napríklad: „Nezaznel termín pri úlohách 2 a 5." Ak nechýbalo nič,
sekciu vynechaj.

## Ak je podkladom surová nahrávka alebo zlý prepis

- Preklepy a chyby rozpoznávania reči oprav ticho, bez komentára.
- Ak je pasáž nezrozumiteľná, napíš `[nezrozumiteľné]` a nedopĺňaj domnienky.
- Ak nevieš rozlíšiť, kto hovorí, píš `hovorca 1`, `hovorca 2` a spýtaj sa na
  mená na konci.

## Ako to zrýchliť nabudúce

Zápis je najlepší vtedy, keď sa robí zo súborov, ktoré máš uložené, a keď
výsledný mail nemusíš kopírovať ručne. Na to slúžia v Claude Projekty
(kontextové súbory a stále inštrukcie) a konektory na Gmail a Kalendár.
Ak ich ešte nepoužívaš, tento skill ti bude fungovať aj tak — len budeš
prepis vkladať a mail kopírovať sám.

## Tvrdé pravidlá

- Žiadne **hodnotiace** prídavné mená. „Produktívne stretnutie", „dôležitá téma",
  „konštruktívna debata" — von. Vecné prídavné mená sú v poriadku a potrebné:
  „trojmesačný odklad", „nový cenník", „druhý dodávateľ".
- Nikdy nezluč dve úlohy do jednej, ani keď súvisia.
- Nikdy nezmeň termín na „čo najskôr". Buď je dátum, alebo `neurčené`.
- Neprikrášľuj konflikt. Ak sa účastníci nezhodli, patrí to do otvorených otázok.
- Ak je podklad taký útržkovitý, že sa z neho nedá spraviť zápis, povedz to rovno
  a vypíš, čo by si potreboval. Nevyrábaj zápis z ničoho.
