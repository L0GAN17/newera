---
name: egov-analyza-defektu
description: Analyzuje defekt v eGOV z popisu, komentárov riešiteľov v JIRA, logov či chybových hlášok (DMS, ÚPVS, subreg) – nájde vzor medzi chybnými a funkčnými prípadmi, rozdelí defekt na nezávislé problémy, určí, kde je loptička (DISIG, DMS tím, biznis, banka), navrhne varianty riešenia s dopadom na delivery a ďalšie kroky delivery managera. Použi vždy, keď používateľ pošle defekt, výsledky testu, error z DMS (E003, E004, E_BAD_VALUE) alebo sa pýta „aké je ďalšie riešenie" či „čo mám spraviť s týmto defektom".
---

# Analýza defektu – eGOV

Delivery manager defekt neopravuje – potrebuje vedieť, **čo presne je rozbité, kto to
má riešiť a či to blokuje prechod do ďalšieho prostredia**. Na tom stavia komunikáciu
s DISIG, DMS tímom aj biznisom.

Známe problémy DMS a súvisiace poznatky sú v `references/znama-dms-problematika.md` –
pozri ich ako prvé, veľa defektov sa opakuje.

## Postup

1. **Zhrň defekt:** prostredie (INT/UAT/LIVE), verzia, formuláre či funkcie, čo
   nefunguje a čo funguje. Ak sú v podklade testovacie prípady, daj ich do tabuľky
   (prípad · vstup · výsledok).
2. **Nájdi vzor.** Čím sa líšia chybné prípady od funkčných? (Napr. banka produktu,
   typ klienta, počet produktov, typ prílohy.) Vzor napíš jednou vetou tučne.
3. **Rozdeľ na nezávislé problémy.** Rôzne chybové kódy, rôzne príčiny alebo rôzni
   riešitelia = samostatné problémy. Riešia sa zvlášť a môžu mať samostatné defekty.
4. **Pre každý problém určí:**
   - príčinu – fakt z logu či komentára, alebo `Možná interpretácia`,
   - kde je loptička – DISIG, DMS tím, biznis, IT prevádzka, externá strana,
   - či ide o **defekt, alebo zmenu** – porovnaj so schválenou analýzou; čo v nej
     nebolo, je zmena (nacenenie), nie chyba DISIG.
5. **Navrhni varianty riešenia** v tabuľke a jedno odporúčanie.
6. **Vyhodnoť dopad na delivery:** severity, ktorý prechod blokuje (prahy v skille
   `egov-schvalovanie-delivery`), či sa oplatí defekt rozdeliť alebo presunúť do
   ďalšej dodávky (vždy len so súhlasom biznisu).
7. **Napíš ďalšie kroky** s vlastníkom a očakávaným výstupom.

## Formát výstupu

```
# Defekt: <názov> (<prostredie> <verzia>)

## 1. Čo vyplýva z podkladu
| Prípad | Vstup | Výsledok |
**Vzor:** …

## 2. Príčina
(pri viacerých problémoch tabuľka: Problém A | Problém B)

## 3. Varianty riešenia
| | Variant A | Variant B |
|---|---|---|
| Čo | | |
| Kto | | |
| Nová dodávka eGOV | áno / nie | |
| Dopad na delivery | | |
**Odporúčanie:** …

## 4. Ďalšie kroky
| # | Krok | Kto | Výstup |

## 5. Dopad na delivery
2–3 vety.
```

Pri jednoduchom defekte sekcie skráť – formát je strop, nie povinná dĺžka.

## Pravidlá

- Ako fakt uvádzaj len to, čo je v popise, komentári alebo logu. Hypotézu označ
  `Možná interpretácia` a napíš, ako ju overiť (napr. „vytiahnuť z logov productType").
- Ak „úspešný" prípad môže byť zavádzajúci (dokument sa uložil, ale možno pod iný
  produkt), označ ho `Potrebné overiť`.
- Uprednostni riešenie **bez novej dodávky eGOV** (napr. úprava číselníka v DMS),
  ak rovnako rieši problém – odblokuje delivery rýchlejšie.
- Hľadaj **úplnú** opravu: vyžiadaj kompletný zoznam hodnôt či prípadov, aby sa
  defekt neopravoval po jednom.
- Biznisové rozhodnutie (či niečo vôbec treba) nerob za biznis – polož otázku.
- Ak defekt obsahuje viac problémov, navrhni jeho rozdelenie – vybavenú časť
  zavrieť, na zvyšok otvoriť nový defekt.
- Na konci ponúkni jednou vetou správy pre riešiteľov (skill `egov-komunikacia`).
