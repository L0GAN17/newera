# Známa problematika – DMS, ÚPVS a súvisiace systémy (eGOV, 2026)

Poznatky z defektov a stretnutí v roku 2026. Stav pri každej položke platí k uvedenému
obdobiu – pred použitím v odpovedi ho over (`Potrebné overiť aktuálny stav`).

## Obsah
1. Triedy a metódy ukladania do DMS
2. Chybové kódy z DMS
3. Číselník „Služba pre CollDoc"
4. Collections dokumenty (konkurzy, LCO)
5. Prílohy
6. ÚPVS / Slovensko.sk
7. Obchodný register (ORSR)
8. SLA a reakčné doby DISIG

---

## 1. Triedy a metódy ukladania do DMS

- DISIG podľa analýzy Q2 ukladá prílohy do **produktovej časti DMS** metódou
  `createProductDocument`.
- **eKolok** patrí do **všeobecnej triedy (GeneralDoc)**, ktorá sa vytvára metódou
  `createGeneralDocument` – tá v pôvodnom zadaní nebola. DISIG ju v 9/2026 dorábal
  bez nároku na úhradu (ústretovosť, nie priznanie chyby).
- docType `GENDT0011` patrí pod GeneralDoc – použitý v `createProductDocument` vráti E003.
- Collections dokumenty používajú docType `CLLDT…` (napr. `CLLDT0023`).
- V DMS musia existovať **skupiny / priečinky**, kam majú podania padať; ich chýbanie
  spôsobilo neuloženie (vytvoril ich DMS tím, 9/2026).

## 2. Chybové kódy z DMS

| Kód | Význam | Typická príčina |
|---|---|---|
| E003 – DocType not set correctly | Nesprávny docType pre metódu | GeneralDoc docType poslaný cez `createProductDocument` |
| E004 – Error during batch update … ServiceInstanceID presahuje maximálnu dĺžku (64) | Pole je dlhšie ako 64 znakov | Jeden dokument naviazaný na veľa produktov (36 čísel = 288 znakov) |
| FNRCE0010E E_BAD_VALUE … CollDoc.ServiceID nie je v rozsahu povolených hodnôt | Hodnota nie je v číselníku | productType zo subregu chýba v číselníku „Služba pre CollDoc" |
| EJBTransactionRolledbackException (obalová chyba) | Rollback transakcie | Pozri vnorenú príčinu (spravidla jedna z vyššie) |

K limitu 64 znakov: biznis (9/2026) uviedol, že jeden dokument pre desiatky produktov
v praxi nenastáva a úpravu nepožaduje. Podľa DISIG DMS limit neskôr upravil –
`Potrebné overiť`.

## 3. Číselník „Služba pre CollDoc"

- eGOV posiela do DMS **productType tak, ako príde zo subregu** (granulárne hodnoty,
  napr. `S_M_BU_P`, `KU_1`).
- **RB produkty:** DMS tím doplnil do číselníka granulárne hodnoty 1:1 (napr. RB – Účet
  `S_M_BU_P`, RB – Kasička `S_M_SS`, RB – Pôžička `G_143`) → RB prípady sa ukladajú.
- **TB karty:** v číselníku sú agregované – kreditné karty `KK`, debetné karty `DK`.
  Granulárna hodnota (napr. `KU_1`) preto neprejde.
- Číselník teda kombinuje dva prístupy (granulárny pri RB, agregovaný pri TB kartách) –
  či je to zámer, je `Potrebné overiť` s DMS tímom.
- Varianty riešenia: (A) DMS doplní alebo namapuje TB hodnoty – bez dodávky eGOV;
  (B) eGOV mapuje hodnoty subregu na agregované – dodávka + údržba mapovania;
  (C) Collections ukladať bez produktu. Vždy si vyžiadaj **kompletný zoznam** TB
  hodnôt zo subregu, aby sa neopravovalo po jednom.

## 4. Collections dokumenty (konkurzy, LCO)

- Formuláre k prihláškam: Podanie prihlášky pohľadávky, Súhrnná prihláška
  nezabezpečených pohľadávok, Všeobecné podanie v súvislosti s insolvenčným konaním.
- Pôvodne sa ukladali **len pod rodné číslo / IČO**, bez produktov – fungovalo.
  Nové biznisové údaje (produkty) v Q2 toto správanie zmenili.
- Biznis (Mirka, 9/2026): pre konkurzy + Late Collections produktové členenie
  nepotrebujú. Stále otvorené: neukladanie pri právnickej osobe (IČO).
- DISIG tvrdí, že implementoval podľa špecifikácie; rozdiel v očakávaní (napr.
  vyhľadanie pod rodným číslom) považuje za vec dizajnu. Porovnaj s odsúhlaseným
  Excelom pravidiel ukladania.

## 5. Prílohy

- Do DMS sa vkladajú **len nepodpísané** dokumenty (dohoda). Podpísaná príloha môže
  byť príčinou neuloženia.
- **Diakritika** v názve prílohy sa zobrazovala ako otázniky – podľa DISIG problém
  na strane DMS.
- **Veľa príloh / veľké prílohy:** ukladanie trvá dlho, spojenie spadne na timeout,
  eGOV nedostane potvrdenie a skúša znova → dokument sa neuloží alebo uloží viackrát.
  Timeout sa predĺžil na 3 minúty, ani to nestačilo; riešiť na strane DMS.
- Požiadavka Q4: filtrovanie neuložených podaní a opakované uloženie **po jednom**
  (tlačidlo + atribút v gride), nie hromadný skript.

## 6. ÚPVS / Slovensko.sk

- **FIX** je testovacie prostredie ÚPVS; podania z testu nemusia mať reálnu
  protistranu ani odpoveď.
- Víkendová odstávka ÚPVS s novou verziou portálu spôsobila deň, keď sa na LIVE
  nedali sťahovať správy; DISIG urgentne dodal opravnú verziu (cca 3 MD, nad rámec).
  Vedľajší efekt: zjednotenie testovacej a produkčnej verzie – netreba dodávať dve verzie.
- Pri chybe odoslania (napr. všeobecné podanie na schvaľovateľa) over, či error
  pochádza z aktuálneho testu, alebo z obdobia pred nastavením subjektov – DISIG to
  potrebuje vedieť.
- Nesprávne nasadený konfig (neprevzaté app settings) viedol k subjektu bez adresy;
  adresu vie biznis nastaviť sám.

## 7. Obchodný register (ORSR)

- Nový zákon o obchodnom registri (od 17.8.2026) priniesol nové verzie formulárov;
  DISIG aktualizoval schémy.
- Ministerstvo spravodlivosti mení verzie opakovane a komunikuje slabo – rátaj
  s ďalšími legislatívnymi úpravami.

## 8. SLA a reakčné doby DISIG

- Zmluvné SLA existujú len pre **produkčné incidenty**: najvyššia priorita 2 dni,
  stredná 5 dní, najnižšia 20 dní (podľa DISIG – `Potrebné overiť` v zmluve).
- Pre defekty na testovacích prostrediach SLA nie je – funguje „džentlmenská dohoda".
- DISIG interne fixnuté defekty štandardne neoznačuje; „fixnuté" pre nich znamená
  „dodané". Keď defekt prehadzuješ na DISIG, napíš im aj do chatu.
