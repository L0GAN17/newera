---
name: egov-nove-know-how
description: Premení nový materiál k eGOV (procesný dokument, screenshot, pravidlo CAB/ARB, release kalendár, JIRA workflow, akceptačný proces, odpoveď experta) na použiteľné projektové know-how podľa Learning protokolu – vytiahne pravidlá, checklist, dopady na INT/UAT/LIVE a CAB a navrhne presné doplnenie do znalostného súboru alebo referencie skillu. Použi vždy, keď používateľ nahrá nový materiál a chce ho „zapracovať", „naučiť sa", „doplniť do knowledge base" alebo aktualizovať pravidlá.
---

# Nové know-how – eGOV

Cieľ nie je len zhrnúť materiál, ale premeniť ho na pravidlá, ktoré agent a jeho
skilly budú nabudúce používať. Znalosti žijú v `znalosti/*.md` a v referenciách
skillov (napr. `egov-schvalovanie-delivery/references/`).

## Výstup – vždy v tomto poradí

1. **Typ materiálu** – approval proces, release proces, CAB pravidlo, ARB pravidlo,
   JIRA workflow, delivery požiadavka, meeting transcript, akceptačné kritériá,
   akceptačný protokol, testovací proces, prevádzková dokumentácia, rozhodovací
   strom, checklist, iné. Ak nie je jasný: `Nejasné z podkladu`.
2. **Stručné zhrnutie** – 2–4 vety.
3. **Nové pravidlá a poznatky** – len priamo z materiálu: pravidlá, povinné podmienky,
   schvaľovacie kroky, stavy, rozhodovacie kritériá, role, termíny, výnimky.
4. **Dopad na delivery managera** – čo bude robiť inak.
5. **Dopad na INT / UAT / LIVE.**
6. **Dopad na CAB / ARB / akceptáciu.**
7. **Checklist pre prax** – zaškrtávací zoznam.
8. **Otázky na overenie** – čo z materiálu nie je jednoznačné.
9. **Navrhované doplnenie** – presný Markdown text a cieľový súbor (pozri nižšie).
10. **Čo zostáva nejasné z podkladu.**

## Kam patrí nové know-how

| Obsah | Cieľový súbor |
|---|---|
| Rola, štýl výstupov | `znalosti/ABOUT_ME.md` |
| Kontext aplikácie, flow, dodávateľ | `znalosti/PROJECT_CONTEXT.md` a sekcia Kontext v agentovi |
| CAB, release, stavy, akceptácia | `znalosti/APPROVAL_PROCESSES.md` + `egov-schvalovanie-delivery/references/cab-pravidla.md` |
| Release kalendár | `release-kalendar-*.md` + zoznamy v `scripts/cab_kontrola.py` |
| JIRA pasce a chybové hlášky | `egov-schvalovanie-delivery/references/jira-poucenia.md` |
| DMS, ÚPVS, technické poznatky z defektov | `egov-analyza-defektu/references/znama-dms-problematika.md` |
| Chyby prepisu, nové mená | `egov-zapis-zo-stretnutia/references/prepisove-chyby.md` a tabuľka Ľudia v agentovi |
| Šablóna zápisu | `znalosti/MEETING_SUMMARY_TEMPLATE.md` |

Ak obsah nepatrí nikam, navrhni nový súbor (napr. `ARB_RULES.md`,
`TESTING_RULES.md`, `DECISION_TREES.md`).

## Pravidlá

- Nič nad rámec materiálu. Čo je nejasné, zostáva v bodoch 8 a 10.
- Ak nové pravidlo **odporuje** existujúcemu, ukáž obe znenia vedľa seba a spýtaj sa,
  ktoré platí. Staré pravidlo potichu neprepisuj.
- Vo VS Code navrhni zmenu súboru ako konkrétnu úpravu; zapíš ju až po potvrdení.
- Pri zmene release kalendára uprav súčasne tabuľku aj skript a over ho
  (`python scripts/cab_kontrola.py kalendar`).
