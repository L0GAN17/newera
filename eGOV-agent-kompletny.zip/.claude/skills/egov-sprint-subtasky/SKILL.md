---
name: egov-sprint-subtasky
description: Navrhne sub-tasky do JIRA pod story „eGOV – Delivery management" na nový dvojtýždňový šprint – z posledných zápisov a ďalších krokov projektu, v štýle predchádzajúcich šprintov, s popisom do JIRA a prioritou; na požiadanie pripraví aj krátke odprezentovanie na planning. Použi vždy, keď používateľ chce „subtasky do sprintu", „tasky do JIRA na nový šprint", „čo mám dať do planningu" alebo pošle zoznam subtaskov z minulého šprintu.
---

# Sub-tasky do šprintu – eGOV

Sub-tasky patria pod story **„eGOV – Delivery management"**, vlastní ich delivery
manager a pokrývajú jeho prácu na dvojtýždňový šprint.

## Opakujúce sa sub-tasky

Z predchádzajúcich šprintov – zaraď ich vždy, keď práca trvá:

- Support pri testovaní a riešení defektov (DISIG)
- Reporting a zápis úloh zo stretnutí
- Meetingy
- Príprava IR + nasadenie do LIVE

K nim pribúdajú tematické sub-tasky podľa aktuálnych krokov, napríklad
„IS REPLIK – navýšenie verzií formulárov", „Príprava IR pre defekty",
„Q3 – uzavretie výhrad CAB a príprava na UAT".

## Postup

1. Prečítaj posledné zápisy (`zapisy/`) a `stav/otvorene-body.md`, ak existujú.
   Ak používateľ poslal zoznam z minulého šprintu, prevezmi jeho štýl pomenovania.
2. Vyber ďalšie kroky, kde delivery manager **koordinuje alebo niečo dodáva**. Úlohy,
   ktoré celé robia iní (DISIG, biznis), sa objavia len ako súčasť koordinácie.
3. Zoskup ich do 5–10 sub-taskov. Jeden sub-task = jeden sledovateľný výsledok
   v šprinte.
4. Pomenuj ich krátko, v štýle predchádzajúcich šprintov (podstatné meno + kontext,
   kľúč delivery v zátvorke, ak pomôže).

## Výstup

```
# Sub-tasky pre nový šprint – „eGOV – Delivery management"

| # | Názov sub-tasku | Popis (do JIRA) | Priorita |
|---|---|---|---|

## Ďalšie kroky na projekte
(krátky tok, čo na čom závisí – blok kódu so šípkami)

⚠️ Potrebné overiť: … (len ak sa niektorý podklad mohol zmeniť)
```

- Popis do JIRA: 1–2 vety, čo presne sa má v šprinte stať a s kým.
- Priorita: H – blokuje delivery alebo termín; M – ostatné. Predchádzajúce šprinty
  mali väčšinu sub-taskov H.
- Nepridávaj termíny, ktoré nezazneli.

## Odprezentovanie na planningu

Na požiadanie – skill `egov-komunikacia`, typ Planning: po bodoch, neformálne,
jeden riadok na sub-task, na konci hlavné riziko šprintu.
