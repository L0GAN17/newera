---
name: egov-priprava-stretnutia
description: Pripraví podklady na nadchádzajúce stretnutie k eGOV z predchádzajúcich zápisov a otvorených bodov – prehľadovú tabuľku tém na týždenný status s DISIG alebo interný biznis status, prípravu na stretnutie s nadriadeným či scrum mastrom (stav, blokery, riziká, spätná väzba, ďalšie kroky, pravdepodobné otázky) a agendu na zaslanie vopred. Použi vždy, keď používateľ chce „podklady na meeting", „čo si mám prejsť", „prípravu na stretnutie" alebo „tabuľku, čo prejsť s dodávateľom".
---

# Príprava na stretnutie – eGOV

Cieľ: aby delivery manager prišiel na stretnutie s tým, čo je otvorené, čo sa od
minula zmenilo a čo má z koho dostať. Nič nové si nevymýšľaj – pracuješ s tým,
čo zaznelo na predchádzajúcich stretnutiach a v podkladoch.

## Zdroje

1. Posledné zápisy – vo VS Code priečinok `zapisy/` (1–2 posledné z rovnakého typu
   stretnutia plus posledný z druhého typu: status s DISIG ↔ interný biznis status).
2. `stav/otvorene-body.md`, ak existuje.
3. Novšie podklady z konverzácie (defekty, stavy delivery, odpovede kolegov).

Ak podklady chýbajú, povedz, z čoho vychádzaš, a nevypĺňaj medzery domnienkami.

## Postup

1. Vyber všetky **otvorené body a úlohy** z posledných zápisov; vyraď uzavreté.
2. Doplň, čo sa **od minula zmenilo** (nové defekty, odpovede, stavy delivery).
3. Každému bodu priraď **adresáta** (kto má dať odpoveď) a **prioritu**:
   - 🔴 blokuje prechod delivery, LIVE, CAB alebo termín,
   - 🟠 technické a obchodné témy v riešení,
   - 🟡 informatívne, na potvrdenie.
4. Označ údaje, ktoré mohli **zastarať**, do sekcie „Over pred stretnutím".

## Výstup – status meeting (predvolený)

```
# Podklady na status meeting – [s kým]

| # | Prio | Téma | Stav z minula | Čo prejsť / overiť dnes | Adresát |
|---|---|---|---|---|---|

## Čo si pripraviť vopred
- (2–4 body: otvorená delivery, screenshoty, odpovede, ktoré už máš)

## Over pred stretnutím
- (údaje, ktoré sa mohli zmeniť)
```

Ak používateľ chce len tabuľku, daj len tabuľku.

## Výstup – stretnutie s nadriadeným alebo scrum mastrom

1. **Executive summary** – tabuľka Oblasť | Stav (🔴🟡🟢✅) | Jednou vetou
2. **Čo sa podarilo** – krátke body
3. **Aktuálne blokery** – Blocker | Dopad | Čo s tým robím
4. **Riziká** – Riziko | Popis | Prečo je to dôležité
5. **Spätná väzba** – témy, ktoré môže delivery manager otvoriť (kapacity, proces,
   dodávateľ, nástroje)
6. **Ďalšie kroky** – Krok | Kto | Kedy
7. **Pravdepodobné otázky a odpovede** – 3–5 párov
8. **Over pred stretnutím**

## Výstup – agenda na zaslanie vopred

Len na požiadanie: očíslované témy, ku každej jedna veta, čo od účastníkov
potrebujeme. Neformálne, ak ide dodávateľovi alebo kolegom.

## Pravidlá

- Stav z minula píš s odkazom na stretnutie, z ktorého pochádza („podľa statusu
  z [dátum / posledného statusu]").
- Nepriraďuj adresáta, ak z podkladov nie je jasný – uveď `Potrebné overiť`.
- Ak máš aj text na prečítanie (úvod na stretnutie), použi skill `egov-komunikacia`.
