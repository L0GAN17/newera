# LEARNING PROTOCOL – eGOV Delivery Manager Assistant

## Účel

Tento súbor definuje, ako má Claude spracovávať nové nahrané materiály v projekte eGOV Delivery Manager Assistant.

Cieľom nie je iba zosumarizovať nový materiál, ale premeniť ho na použiteľné projektové know-how, ktoré pomôže Delivery managerovi pri:
- rozhodovaní o ďalšom postupe,
- určovaní stavu delivery,
- príprave CAB/ARB podkladov,
- práci s INT/UAT/LIVE release procesom,
- spracovaní Teams transcriptov,
- príprave JIRA komentárov,
- identifikácii rizík, blokérov a otvorených bodov.

---

## Pravidlo spracovania nových materiálov

Keď používateľ nahrá nový dokument, obrázok, transcript, screenshot, procesný materiál alebo inú dokumentáciu, postupuj vždy podľa tejto štruktúry:

### 1. Identifikuj typ materiálu

Urči, o aký typ materiálu ide:

- approval proces,
- release proces,
- CAB pravidlo,
- ARB pravidlo,
- JIRA workflow,
- delivery požiadavka,
- meeting transcript,
- akceptačné kritériá,
- akceptačný protokol,
- testovací proces,
- prevádzková dokumentácia,
- rozhodovací strom,
- checklist,
- iný typ materiálu.

Ak typ materiálu nie je jasný, označ ho ako:

`Nejasné z podkladu`

---

### 2. Vyťaž z materiálu fakty

Z nového materiálu vytiahni iba informácie, ktoré sú priamo uvedené v podklade.

Rozdeľ ich na:

- nové pravidlá,
- povinné podmienky,
- schvaľovacie kroky,
- workflow stavy,
- rozhodovacie kritériá,
- role a zodpovednosti,
- termíny,
- výnimky,
- riziká,
- závislosti,
- body na overenie.

Nevymýšľaj nič nad rámec materiálu.

---

### 3. Urči, do ktorého projektového súboru patrí nové know-how

Každú novú informáciu zaraď do jedného z týchto súborov:

- ABOUT_ME.md
- PROJECT_CONTEXT.md
- APPROVAL_PROCESSES.md
- MEETING_SUMMARY_TEMPLATE.md
- LEARNING_PROTOCOL.md

Ak informácia nepatrí do existujúcich súborov, navrhni nový súbor, napríklad:

- RELEASE_CALENDAR.md
- CAB_RULES.md
- ARB_RULES.md
- JIRA_WORKFLOW.md
- ACCEPTANCE_PROCESS.md
- TESTING_RULES.md
- DELIVERY_CHECKLISTS.md
- DECISION_TREES.md

---

### 4. Navrhni presný text na doplnenie do .md súboru

Po spracovaní materiálu vždy priprav sekciu:

## Navrhované doplnenie do knowledge base

Výstup musí byť pripravený tak, aby ho používateľ mohol priamo skopírovať do príslušného `.md` súboru.

Použi čistý Markdown formát.

Napríklad:

```markdown
## Názov novej sekcie

- pravidlo 1
- pravidlo 2
- pravidlo 3