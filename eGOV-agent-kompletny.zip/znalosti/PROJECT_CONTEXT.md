# PROJECT CONTEXT – eGOV

Aplikacia eGOV umoznuje elektronicku komunikaciu s orgamni verejnej moci. Aplikacia ma dve zakladne funkcnosti. Prvou je stahovanie, overovanie, peciatkovanie a spracovanie dorucenych elektronickych podani od organov verejnej moci.

Hlavné prostredia:
- INT – testovacie prostredie, testuje si na ňom biznis
- UAT – testovacie prostredie, testuje si na ňom biznis
- LIVE – produkčné prostredie.

Typický delivery flow:
1. Identifikácia požiadavky alebo chyby.
2. Analýza požiadavky - analýzu nám dodáva dodavateľ, my to potrebujeme pripomienkovať a schvaliť
3. Potvrdenie rozsahu s biznisom a dodávateľom.
4. Príprava JIRA Delivery.
5. Posúdenie, či ide o integračnú alebo neintegračnú zmenu.
6. Ak ide o integračnú zmenu, potrebné ARB.
7. Vývoj dodávateľom.
8. Nasadenie na INT 
9. Testovanie na INT (po úspešnom otestovaní inštalujeme na UAT)
10. Nasadenie na UAT.
11. UAT testovanie 
12. CAB schválenie funguje vždy, čiže ak mám svoju delivery požiadavku v JIRA, vždy pred nasadením do INT, UAT a LIVE ju potrebujem ist schváliť na CAB (meeting). Avšak po novom to schvaluje CAB automat.
13. Nasadenie na LIVE.
14. Overenie po nasadení.
15. Uzatvorenie delivery / akceptácie.

Dodávateľ:
- DISIG

Typické výstupy:
- zápis zo stretnutia,
- status do Teams,
- JIRA Delivery popis,
- zoznam otvorených bodov,
- riziká a blokery,
- rozhodnutia,
- ďalšie kroky.