# Release kalendár 2026

| Názov release | Small/Large Release | First call INT | Last Call INT | UAT | LIVE |
|---|---|---|---|---|---|
| R2026.01.1 | Small | 7.1. |  | 15.1. | 29.1. |
| R2026.02.1 | Small | 4.2. |  | 18.2. | 25.2. |
| R2026.02 | Large | 7.1. | 15.1. | 22.1. | 12.2. |
| R2026.03.1 | Small | 26.2. |  | 5.3. | 12.3. |

**Failover test DC1 Kopčianska (DR) 19.3.-23.3. (Infraštruktúrny a inštalačný freeze)**

| Názov release | Small/Large Release | First call INT | Last Call INT | UAT | LIVE |
|---|---|---|---|---|---|
| R2026.04.1 | Small | 9.4. |  | 16.4. | 23.4. |
| R2026.05.1 | Small | 29.4. |  | 7.5. | 14.5. |
| R2026.05 | Large | 12.3. | 23.4. | 30.4. | 21.5. |
| R2026.06.1 | Small | 28.5. |  | 11.6. | 18.6. |
| R2026.07.1 | Small | 2.7. |  | 9.7. | 16.7. |
| R2026.08.1 | Small | 29.7. |  | 6.8. | 13.8. |
| R2026.08 | Large | 25.6. | 23.7. | 30.7. | 20.8. |
| R2026.09.1 | Small | 27.8. |  | 3.9. | 10.9. |

**Failover test DC2 Varšavská (DR) 24.9. - 28.9.2026 (Infraštruktúrny a inštalačný freeze)**

| Názov release | Small/Large Release | First call INT | Last Call INT | UAT | LIVE |
|---|---|---|---|---|---|
| R2026.10.1 | Small | 23.9. |  | 1.10. | 8.10. |
| R2026.11.1 | Small | 21.10. |  | 29.10. | 5.11. |
| R2026.11 | Large | 10.9. | 15.10. | 22.10. | 12.11. |
| R2026.12.1 | Small |  |  | 18.11. | 3.12. |
| R2026.12 | Large |  |  | 19.11. | 9.12. |

**Refresh INT 18.11. - 10.12.2026**

**Infraštruktúrny a inštalačný freeze od 11.12.2026**

**TESTY EOY 2026 11.12. - 23.12.2026**




# Workflow stavov delivery / approval procesu

Poznámka: Obrázok zobrazuje workflow prechody medzi stavmi. Hlavné stavy sú čitateľné, drobné texty pri šípkach/prechodoch sú z obrázka nečitateľné.

## Hlavné stavy workflow

- NEW
- READY FOR INT
- APPROVED INT
- READY FOR UAT
- APPROVED UAT
- READY FOR LIVE
- APPROVED LIVE
- DONE
- CANCELED
- ALL

## Zjednodušený postup workflow

1. NEW
2. READY FOR INT
3. APPROVED INT
4. READY FOR UAT
5. APPROVED UAT
6. READY FOR LIVE
7. APPROVED LIVE
8. DONE

## Alternatívne / ukončovacie stavy

- CANCELED



# CAB Automat v JIRA


## Možné výsledky vyhodnotenia automatom

### OK = GO na inštaláciu

OK

splnené všetky požiadavky na inštaláciu

---

### COK = GO na inštaláciu - potrebné bezodkladne opraviť výhrady

COK

výhrady, ktoré nebránia inštalácii

Príklady výhrad:
- Chýbajúca feature na IR
- Chýbajúci link na detailnú analýzu


## PREAPPROVED - OK/COK

PREAPPROVED OK/COK

Dodávka bola vyhodnotená ako OK alebo COK, ale je potrebná kontrola Release manažéra

- DE manažér kontaktuje Release manažéra – ten posúdi, či je možné schváliť DE alebo je potrebné žiadať výnimku od CAB (ísť na CAB)

- Platí pre n.u. prípady:

  - Dodávky vo veľkom release
    - pozn. nenapíše výhradu do CAB Status Notes
    - Platí pre INT/UAT/LIVE

  - Neintegračné dodávky s výsledkom z ARB, t.j. ARB/IARCH/GDPR/SECURITY flag je iný ako NQ
    - pozn. nenapíše výhradu do CAB Status Notes
    - Platí pre INT/UAT/LIVE

  - Pridané IR-ky do už schválených DE na INT
    - pozn. napíše výhradu "Pridaná IR"

  - Plánovaný dátum inštalácie na IR je mimo dátumového okna daného releasu
    - pozn. napíše výhradu "Dátum na IR sa nezhoduje s dátumami pre INT/UAT/LIVE v Release R20xx.xx"
    - Platí pre INT/UAT/LIVE

    - Malý release:
      - Dátum pre INT/UAT/LIVE na IR-ke musí byť z intervalu <Term INT First Call ; Term LIVE> (vrátane Term INT First Call a Term LIVE) v danom malom release

    - Veľký release:
      - dátum pre INT na IR-ke musí byť z intervalu <Term INT First Call ; Term Last Call INT> (vrátane Term INT First Call a Term Last Call INT) v danom veľkom release
      - dátum pre UAT na IR-ke musí byť rovný Term UAT v danom veľkom release
      - dátum pre LIVE na IR-ke musí byť rovný Term LIVE v danom veľkom release

- pozn. Release manažéra kontaktujte v týchto prípadoch:

  - dodávka bola vyhodnotená a je v stave PREAPPROVED(OK/COK) na INT/UAT/LIVE
  - dodávky v stave Ready for INT, ktorých CAB Status = N/A a jediná výhrada je "Dátum na IR sa nezhoduje s dátumami pre INT/UAT/LIVE v Release R20xx.xx"
  - ak bol zmenený Release/Scope na dodávke, ktorá bola v stave Approved INT/UAT/LIVE a následné vyhodnotenie automatom skončilo s výsledkom N/A
  - na dodávke je Evidenčný Epic, ktorý nemá vytvorenú záložku GDPR
  - v prípade neštandardnej situácie


## N/A = NoGO na inštaláciu = žiadanie výnimky od CAB

N/A - žiadanie výnimky od CAB

nesplnené kritické požiadavky

### Medzi kritické požiadavky patrí:

- absolvovanie procesov
- ARB
- GDPR
- Cloud Assesment pre DE typu Cloud(New/Migration alebo Change)
  - Prípadné výhrady z v.u. procesov je potrebné odstrániť pred inštaláciou do LIVE!

- otestovanie a oprava defektov na testovacích prostrediach

- splnenie podmienok vyšpecifikovaných v Akceptačných kritériách a akceptovaním Akceptačného protokolu
  - Pre zmeny typu Non-Integrational sa spravidla Akceptačné kritéria a Akceptačný protokol nevyžadujú


## Vplyv výsledkov testov na INT a UAT prostrediach na vyhodnotenie automatom

### Testy:

- OK:

  TCs - Pass / TCs - Total >= 95%

- COK:

  95% > TCs - Pass / TCs - Total >= 85%

- N/A:

  85% > TCs - Pass / TCs - Total

---

### Počet defektov:

#### Ready for INT:

- Postimplementačné DE vstupujúce do INT prostredia, v ktorých sa fixujú defekty, ktoré už boli nainštalované v predošlých DE
  - pozn. napíše výhradu "Neštandardný stav defektov" alebo "Neštandardný stav testov"
  - Je potrebné kontaktovať Release manažéra – ten posúdi, či je možné schváliť DE alebo je potrebné žiadať výnimku od CAB(ísť na CAB)

| OPEN DEFECTS | OK | COK | N/A |
|---|---:|---:|---:|
| Severity A+ | 0 | 0 | x > 0 |
| Severity A | 0 | 0 | x > 0 |
| Severity B | 0 | 0 | x > 0 |
| Severity C | 0 | 0 | x > 0 |

---

#### Ready for UAT:

| OPEN DEFECTS | OK | COK | N/A |
|---|---:|---:|---:|
| Severity A+ | 0 | 0 | x > 0 |
| Severity A | 0 | 0 | x > 0 |
| Severity B | ≤5 | 5 < x ≤ 7 | x > 7 |
| Severity C | ≤10 | 10 < x ≤ 12 | x > 12 |

---

#### Ready for LIVE:

| OPEN DEFECTS | OK | COK | N/A |
|---|---:|---:|---:|
| Severity A+ | 0 | 0 | x > 0 |
| Severity A | 0 | 0 | x > 0 |
| Severity B | 0 | 0 < x ≤ 2 | x > 2 |
| Severity C | 0 | 0 < x ≤ 4 | x > 4 |

## Jednotlivé stavy vo workflow pre issue type DELIVERY

- NEW - nové vytvorené požiadavky bez prihlásenia na schvaľovanie

- READY FOR INT - požiadavka prihlásená na schválenie inštalácie do INT
  - PREAPPROVED INT - predschválená požiadavka na inštaláciu do INT (potrebné kontaktovať Release manažéra)
  - APPROVED INT - schválená požiadavka na inštaláciu do INT

- READY FOR UAT - požiadavka prihlásená na schválenie inštalácie do UAT
  - PREAPPROVED UAT - predschválená požiadavka na inštaláciu do UAT (potrebné kontaktovať Release manažéra)
  - APPROVED UAT - schválená požiadavka na inštaláciu do UAT

- READY FOR LIVE - požiadavka prihlásená na schválenie inštalácie do LIVE
  - PREAPPROVED LIVE - predschválená požiadavka na inštaláciu do UAT (potrebné kontaktovať Release manažéra)
  - APPROVED LIVE - schválená požiadavka na inštaláciu do UAT

- DONE - ukončená požiadavka, požiadavka po nainštalovaní do LIVE

- CANCELLED - zrušená požiadavka


## Kontrola dátumu inštalácie na IR voči dátumovému oknu releasu

Vyžaduje sa, aby dátum inštalácie na IR bol v rámci dátumového okna daného releasu:

- Malý release:
  - Dátum pre INT/UAT/LIVE na IR-ke musí byť z intervalu <Term INT First Call ; Term LIVE> (vrátane Term INT First Call a Term LIVE) v danom malom release

- Veľký release:
  - dátum pre INT na IR-ke musí byť z intervalu <Term INT First Call ; Term Last Call INT> (vrátane Term INT First Call a Term Last Call INT) v danom veľkom release
  - dátum pre UAT na IR-ke musí byť rovný Term UAT v danom veľkom release
  - dátum pre LIVE na IR-ke musí byť rovný Term LIVE v danom veľkom release

Inak bude DE vyhodnotená ako Preapproved

- pozn. napíše výhradu "Dátum na IR sa nezhoduje s dátumami pre INT/UAT/LIVE v Release R20xx.xx"
- Platí pre INT/UAT/LIVE

## 1 Zaraďovanie Delivery do Release

- Dodávku do release-u prihlasuje Delivery manager vytvorením Delivery objektu (Issue type) v JIRA podľa aktuálne platnej štruktúry.
- Integračné aj neintegračné dodávky sa prihlasujú rovnako (rozdiel je v uvádzaní povinných atribútov)
- Delivery je po prekliknutí sa do stavu Ready for INT/UAT/LIVE zároveň aj žiadavkou o zaradenie do príslušného release-u.

## 1.1 Zodpovednosti pri vytváraní a prihlasovaní Delivery do Release

### Delivery - READY FOR INT - špecifiká Cloud delivery

záložka INT Criteria:

- Agreed Funding - informácia o tom, či je dohodnuté financovanie (YES/NO)
- Outsourcing - YES/NO
- Risk Analysis - link na úložisko Riskovej analýzy

---

### Delivery - NEW/READY FOR INT

- Vytvorenie novej dodávky v Release (zodp. Delivery manager/KC koordinátor/Scrum master)
  - Dodávka v stave NEW
  - Zaradená v konkrétnom release

- Prihlásenie dodávky na CAB – pre INT inštaláciou (zodp. Delivery manager/KC koordinátor/Scrum master)
  - ARB - absolvované, so výsledkom OK, COK
  - SECURITY - Súhlas s riešením za IT security a schválená bezpečnostná štúdia
  - GDPR - Súhlas s riešením za GDPR
  - IARCH - súhlas s riešením za Infraštruktúrnych architektov
  - ITOPS Statement - dohodnutá kapacita IT OPS (Yes - potvrdené kapacity, Not Required - nepotrebujem dohadovať kapacity)
  - Hotová Detailná analýza
  - Vytvorený Delivery plán
  - Alokované zdroje na testerov v tribe-och
  - Vyšpecifikované Integračné závislosti
  - Vyšpecifikované závislosti na iných ID v rámci scope daného release
  - Na IR pridané konkrétne Features
  - Dodávka v stave READY FOR INT, pričom sú splnené nasledujúce podmienky:
  - Vytvorený subtask (alebo viacero) pre Instalation Request (IR)
  - Doplnený Test/Defect manager na záložke Testing

## Delivery - READY FOR UAT

- Prihlásenie dodávky na CAB – pred UAT inštaláciou (zodp. Delivery manager/KC koordinátor/Scrum master)
  - Akceptačné kritériá na počet defektov pri prechode prostrediami (INT - UAT):
    - A - 0
    - B - 5
    - C - podľa dohody

  - Dodávka v stave READY FOR UAT, pričom sú splnené nasledujúce podmienky:
    - Akceptovaná dodávka za Biznis vlastníka/Product Ownera pre inštaláciu do UAT
    - Dodaná prevádzková dokumentácia na ITOPS
    - Uvedená informácia ohľadne potreby Performance testov (či sú plánované/vykonané/nepožadované)
    - Uvedená informácia ohľadne potreby Penetračných testov (či sú plánované/vykonané/nepožadované)
    - Uvedená informácia ohľadne potreby Disaster Recovery Tests (či sú plánované/vykonané/nepožadované)
    - Súhlas za školiace stredisko
    - Uvedený počet plánovaných a prejdených Test Case-ov na INT
    - Uvedený počet otvorených defektov na INTe (podľa severity) - automatizované doťahovanie cez Recalculate Defect Count

---

## Delivery - READY FOR LIVE

- Prihlásenie dodávky na CAB – pred LIVE inštaláciou (zodp. Delivery manager/KC koordinátor/Scrum master)

- Akceptačné kritériá na počet defektov pri prechode prostrediami (UAT - LIVE):
  - A - 0
  - B - 0
  - C - podľa dohody

- Dodávka v stave READY FOR LIVE, pričom sú splnené nasledujúce podmienky:
  - Akceptovaná dodávka za Biznis vlastníka/Product Ownera pre inštaláciu do LIVE
  - Dodaná prevádzková dokumentácia na ITOPS
  - Uvedená informácia ohľadne potreby Performance testov (či sú vykonané/nepožadované)
  - Uvedená informácia ohľadne potreby Penetračných testov (či sú vykonané/nepožadované)
  - Uvedená informácia ohľadne potreby Disaster Recovery Tests (či sú vykonané/nepožadované)
  - Uvedený počet plánovaných a prejdených Test Case-ov na UAT
  - Uvedený počet otvorených defektov na UAT (podľa severity) - automatizované doťahovanie cez Recalculate Defect Count
  - Akceptovaný Akceptačný Protokol - samostatný sub-task za Business vlastníka, IT Prevádzku a IT Security

## Akceptačné kritériá a akceptačný protokol


Každá zmena aplikovaná do živej prevádzky musí prejsť procesom akceptácie!

---

### INTEGRAČNÉ ZMENY

Pre požiadavky typu Integrational (integračné zmeny), ktoré si vyžadujú zmeny aplikácií, môžu byť tieto nasadené do LIVE prevádzky až po splnení podmienok vyšpecifikovaných v Akceptačných kritériách a akceptovaní Akceptačného protokolu nasledujúcimi subjektami:

- Business vlastník, resp. Garant aplikácie (Zákazník)
- Riaditeľ odboru prevádzky IT, resp. zodpovedný B-2 manager (Preberajúci)
- Vedúci oddelenia IT security

---

### NEINTEGRAČNÉ ZMENY

- Neintegračné, jednoplatformové, nezávislé zmeny typu Non Integrational, ktoré nijak zásadne nemenia funkčnosť IT aplikácie z pohľadu jej prevádzky a performance nevyžadujú Akceptačné kritériá.

---

Zakazuje sa riešiť Integračnú zmenu v dvoch samostatných Non Integrational zmenách a obchádzať platný proces a Akceptačné kritériá.

! Všetky vyššie popísané zmeny bezohľadu na typ musia byť v zmysle platného Release & Deployment procesu prejednané a schválené na CAB výbore.

---

### Akceptačné kritériá

- Vyžiadanie špecifikácie Akceptačné kritéria spolu s platným návrhom zmeny (Finálnou Ponukou vrátane obrázku navrhnutého riešenia z EA Modelu) je nevyhnutným predpokladom pre vstup do INT prostredia.
- Žiadosť o Akceptačné kritériá sa smeruje vždy na príslušného TímLídra (môže ich byť viacero) zodpovedného za L2 prevádzku danej aplikácie ktorej sa uvedená zmena týka.
- Splnenie Akceptačných kritérií a dodanie všetkých vyšpecifikovaných náležitostí (napr. Aktualizácia prevádzkovej dokumentácie, Performance/DR Testy, Povolený počet Defektov ...) je podkladom Akceptačného protokolu nevyhnutného pre nasadenie zmeny do LIVE prevádzky.

---

### Akceptačný protokol

- Vytvorenie a zaslanie žiadosti na akceptáciu Akceptačného protokolu je potrebné urobiť pred prepnutím Delivery do stavu Ready for LIVE
- Akceptačný protokol za všetkých schvaľovateľov má byť akceptovaný pred CAB meetingom, na ktorom sa schvaľuje vstup do LIVE

---

Akceptáciou sa IT Prevádzka zaväzuje vykonávať definované aktivity nevyhnutné na prevádzkovanie danej dodávky tak, aby zabezpečila dohodnuté parametre služby.

