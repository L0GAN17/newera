# MEETING SUMMARY TEMPLATE

## Účel súboru

Tento súbor definuje pravidlá a štruktúru, podľa ktorej má Claude spracovávať meeting transcripty pre projekt eGOV.

Používa sa najmä pre:
- Teams transcripty,
- zápisy zo stretnutí,
- status meetingy s dodávateľom,
- status meetingy s biznisom,
- interné delivery meetingy,
- prípravu follow-up správ,
- identifikáciu rozhodnutí, úloh, rizík a otvorených bodov.

---

## Overený prompt používateľa, podľa ktorého vytvárať zápisy zo stretnutí:
Promnt:

Spracuj nasledujúci prepis online meetingu do profesionálneho zápisu podobného výstupu z AI meeting nástroja typu Plaud Note Pro.

Tvojou úlohou je vytvoriť vecný, prehľadný a použiteľný zápis v slovenskom jazyku.
Nevymýšľaj žiadne nové informácie. Pracuj výhradne s obsahom prepisu.
Ak niečo z prepisu nie je jasné, označ to ako „Nejasné z prepisu“ alebo „Potrebné overiť“.
Ak robíš interpretáciu, výslovne ju označ ako „Možná interpretácia“.
Dôležité pravidlo: Ak informácia nie je priamo uvedená v prepise, nesmieš ju doplniť ako fakt. Môžeš ju uviesť iba v časti „Potrebné overiť“ alebo „Možná interpretácia“. Nepriraďuj úlohy osobám, ak to z prepisu jasne nevyplýva.

Zápis štruktúruj nasledovne:

1. Názov stretnutia
- Navrhni krátky a výstižný názov meetingu podľa obsahu.

2. Stručné zhrnutie meetingu
- V 5 až 8 bodoch zhrň, o čom meeting bol.
- Zachyť hlavný cieľ stretnutia, najdôležitejšie témy a výsledok diskusie.

3. Hlavné diskutované témy
Pre každú tému vytvor samostatnú sekciu:
- Názov témy
- Čo sa riešilo
- Kto sa k téme vyjadroval, ak je to z prepisu zrejmé
- Dôležité zistenia
- Otvorené otázky alebo nejasnosti
- Navrhované riešenie alebo ďalší postup

4. Prijaté rozhodnutia
Vytvor tabuľku:
| Rozhodnutie | Kontext | Zodpovedná osoba/tím | Dopad | Poznámka |
Ak rozhodnutie nebolo jasne prijaté, neuvádzaj ho ako rozhodnutie, ale presuň ho do časti „Otvorené body“.

5. Akčné úlohy / Action items
Vytvor tabuľku:
| Úloha | Zodpovedná osoba/tím | Termín | Priorita | Kontext |
Ak v prepise nie je uvedený vlastník alebo termín, napíš „Neuvedené v prepise“.

6. Riziká, blokery a závislosti
Vytvor tabuľku:
| Riziko / blocker | Popis | Dopad | Navrhované riešenie | Vlastník |
Zachyť najmä veci, ktoré môžu ovplyvniť termín, dodávku, testovanie, nasadenie, schválenie alebo biznis proces.

7. Otvorené body
Vypíš všetko, čo ostalo nedoriešené:
- otázky bez odpovede,
- témy, ktoré treba overiť,
- závislosti na iných tímoch,
- body, ku ktorým nepadlo jasné rozhodnutie.

8. Manažérsky súhrn
Napíš krátky súhrn pre manažment:
- aktuálny stav,
- hlavné riziká,
- čo je potrebné rozhodnúť alebo zabezpečiť,
- odporúčaný ďalší krok.

9. Technický / projektový súhrn
Napíš súhrn pre IT analytika, delivery manažéra, vývojárov a testerov:
- čo sa mení,
- aké sú dopady na systém/proces,
- čo treba analyzovať,
- čo treba otestovať,
- aké sú závislosti na prostrediach, dodávkach, release, CAB, UAT alebo LIVE, ak sa o tom hovorilo.

10. Finálny záver
Na konci vytvor krátky záver:
- čo bolo dohodnuté,
- čo treba spraviť ako ďalšie,
- kto má pokračovať v riešení.

Štýl výstupu:
- Použi formálny, vecný a profesionálny jazyk.
- Oprav zjavné chyby z automatického prepisu, ale nemeň význam.
- Zachovaj mená osôb, systémov, aplikácií, projektov a termínov tak, ako sú uvedené v prepise.
- Nepoužívaj všeobecné frázy bez obsahu.
- Výstup má byť vhodný na vloženie do e-mailu, Confluence, Jira alebo Teams.

Kontext meetingu:
Ide o projektový / delivery meeting k aplikácii eGOV
Cieľom stretnutia bol aktualny status ktorý sa opakuje každý týžden.
Výstup potrebujem ako formálny zápis pre interný tím, biznis vlastníka a dodávateľa.
Tu je prepis meetingu:



